﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CourseLibrary
{
    public static class Course
    {

        public static Dictionary<string, string> courseRoomNumbers = new Dictionary<string, string>()
        {
            {"CS101","3004"},
            {"CS102","4501"},
            {"CS103","6755"},
            {"NT110","1244"},
            {"CM241","1411"}
        };

        public static Dictionary<string, string> courseInstructorNames = new Dictionary<string, string>()
        {
            {"CS101","Haynes"},
            {"CS102","Alvarado"},
            {"CS103","Rich"},
            {"NT110","Burke"},
            {"CM241","Lee"}
        };

        public static Dictionary<string, string> courseMeetingTimes = new Dictionary<string, string>()
        {
            {"CS101","8:00 AM"},
            {"CS102","9:00 AM"},
            {"CS103","10:00 AM"},
            {"NT110","11:00 AM"},
            {"CM241","1:00 PM"}
        };

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PetLibrary
{
    public class Pet
    {

        public string Name { get; set; }
        public string Type { get; set; }
        public int Age { get; set; }


        public Pet() { } // Default Constructor

        public Pet(string name, string type, int age)
        {
            Name = name;
            Type = type;
            Age = age;
        }


        // Display Text Method
        public string StringifyPet() {
            string petString = $"Pet Name: {Name}\nPet Type: {Type}\nPet Age: {Age}";
            return petString;
        }
    }
}

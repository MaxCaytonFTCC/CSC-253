﻿namespace WinUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.exitButton = new System.Windows.Forms.Button();
            this.resultListBox = new System.Windows.Forms.ListBox();
            this.searchButton = new System.Windows.Forms.Button();
            this.instructionLabel = new System.Windows.Forms.Label();
            this.rangesLabel = new System.Windows.Forms.Label();
            this.bedroomMinTextBox = new System.Windows.Forms.TextBox();
            this.bedroomMaxTextBox = new System.Windows.Forms.TextBox();
            this.bathroomMaxTextBox = new System.Windows.Forms.TextBox();
            this.bathroomMinTextBox = new System.Windows.Forms.TextBox();
            this.squareFeetMaxTextBox = new System.Windows.Forms.TextBox();
            this.squareFeetMinTextBox = new System.Windows.Forms.TextBox();
            this.resultsLabel = new System.Windows.Forms.Label();
            this.noteLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(1037, 842);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(88, 43);
            this.exitButton.TabIndex = 0;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // resultListBox
            // 
            this.resultListBox.FormattingEnabled = true;
            this.resultListBox.ItemHeight = 20;
            this.resultListBox.Location = new System.Drawing.Point(487, 52);
            this.resultListBox.Name = "resultListBox";
            this.resultListBox.Size = new System.Drawing.Size(638, 784);
            this.resultListBox.TabIndex = 1;
            // 
            // searchButton
            // 
            this.searchButton.Location = new System.Drawing.Point(122, 406);
            this.searchButton.Name = "searchButton";
            this.searchButton.Size = new System.Drawing.Size(185, 37);
            this.searchButton.TabIndex = 2;
            this.searchButton.Text = "Apply and Search";
            this.searchButton.UseVisualStyleBackColor = true;
            this.searchButton.Click += new System.EventHandler(this.searchButton_Click);
            // 
            // instructionLabel
            // 
            this.instructionLabel.AutoSize = true;
            this.instructionLabel.Location = new System.Drawing.Point(80, 184);
            this.instructionLabel.Name = "instructionLabel";
            this.instructionLabel.Size = new System.Drawing.Size(266, 40);
            this.instructionLabel.TabIndex = 3;
            this.instructionLabel.Text = "Specifiy your data range, then press \r\n\'Apply and Search\' to view results";
            this.instructionLabel.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // rangesLabel
            // 
            this.rangesLabel.AutoSize = true;
            this.rangesLabel.Location = new System.Drawing.Point(12, 245);
            this.rangesLabel.Name = "rangesLabel";
            this.rangesLabel.Size = new System.Drawing.Size(312, 100);
            this.rangesLabel.TabIndex = 4;
            this.rangesLabel.Text = "Bedroom Count Range:                              to\r\n\r\nBathroom Count Range     " +
    "                         to\r\n\r\nSquare Feet Range:                              t" +
    "o";
            // 
            // bedroomMinTextBox
            // 
            this.bedroomMinTextBox.Location = new System.Drawing.Point(195, 245);
            this.bedroomMinTextBox.Name = "bedroomMinTextBox";
            this.bedroomMinTextBox.Size = new System.Drawing.Size(100, 26);
            this.bedroomMinTextBox.TabIndex = 5;
            // 
            // bedroomMaxTextBox
            // 
            this.bedroomMaxTextBox.Location = new System.Drawing.Point(330, 245);
            this.bedroomMaxTextBox.Name = "bedroomMaxTextBox";
            this.bedroomMaxTextBox.Size = new System.Drawing.Size(100, 26);
            this.bedroomMaxTextBox.TabIndex = 6;
            // 
            // bathroomMaxTextBox
            // 
            this.bathroomMaxTextBox.Location = new System.Drawing.Point(330, 286);
            this.bathroomMaxTextBox.Name = "bathroomMaxTextBox";
            this.bathroomMaxTextBox.Size = new System.Drawing.Size(100, 26);
            this.bathroomMaxTextBox.TabIndex = 8;
            // 
            // bathroomMinTextBox
            // 
            this.bathroomMinTextBox.Location = new System.Drawing.Point(195, 286);
            this.bathroomMinTextBox.Name = "bathroomMinTextBox";
            this.bathroomMinTextBox.Size = new System.Drawing.Size(100, 26);
            this.bathroomMinTextBox.TabIndex = 7;
            // 
            // squareFeetMaxTextBox
            // 
            this.squareFeetMaxTextBox.Location = new System.Drawing.Point(307, 319);
            this.squareFeetMaxTextBox.Name = "squareFeetMaxTextBox";
            this.squareFeetMaxTextBox.Size = new System.Drawing.Size(100, 26);
            this.squareFeetMaxTextBox.TabIndex = 10;
            // 
            // squareFeetMinTextBox
            // 
            this.squareFeetMinTextBox.Location = new System.Drawing.Point(172, 319);
            this.squareFeetMinTextBox.Name = "squareFeetMinTextBox";
            this.squareFeetMinTextBox.Size = new System.Drawing.Size(100, 26);
            this.squareFeetMinTextBox.TabIndex = 9;
            // 
            // resultsLabel
            // 
            this.resultsLabel.AutoSize = true;
            this.resultsLabel.Location = new System.Drawing.Point(713, 29);
            this.resultsLabel.Name = "resultsLabel";
            this.resultsLabel.Size = new System.Drawing.Size(205, 20);
            this.resultsLabel.TabIndex = 11;
            this.resultsLabel.Text = "House Prices Within Criteria";
            // 
            // noteLabel
            // 
            this.noteLabel.AutoSize = true;
            this.noteLabel.Location = new System.Drawing.Point(105, 476);
            this.noteLabel.Name = "noteLabel";
            this.noteLabel.Size = new System.Drawing.Size(234, 40);
            this.noteLabel.TabIndex = 12;
            this.noteLabel.Text = "Note: Entering negative values \r\nwill cause the filter to be ignored";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1175, 895);
            this.Controls.Add(this.noteLabel);
            this.Controls.Add(this.resultsLabel);
            this.Controls.Add(this.squareFeetMaxTextBox);
            this.Controls.Add(this.squareFeetMinTextBox);
            this.Controls.Add(this.bathroomMaxTextBox);
            this.Controls.Add(this.bathroomMinTextBox);
            this.Controls.Add(this.bedroomMaxTextBox);
            this.Controls.Add(this.bedroomMinTextBox);
            this.Controls.Add(this.rangesLabel);
            this.Controls.Add(this.instructionLabel);
            this.Controls.Add(this.searchButton);
            this.Controls.Add(this.resultListBox);
            this.Controls.Add(this.exitButton);
            this.Name = "Form1";
            this.Text = "House Price Analysis";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.ListBox resultListBox;
        private System.Windows.Forms.Button searchButton;
        private System.Windows.Forms.Label instructionLabel;
        private System.Windows.Forms.Label rangesLabel;
        private System.Windows.Forms.TextBox bedroomMinTextBox;
        private System.Windows.Forms.TextBox bedroomMaxTextBox;
        private System.Windows.Forms.TextBox bathroomMaxTextBox;
        private System.Windows.Forms.TextBox bathroomMinTextBox;
        private System.Windows.Forms.TextBox squareFeetMaxTextBox;
        private System.Windows.Forms.TextBox squareFeetMinTextBox;
        private System.Windows.Forms.Label resultsLabel;
        private System.Windows.Forms.Label noteLabel;
    }
}


﻿/**
* 12/5/2023
* CSC 253
* Max Cayton
* This program lets the user enter information about their pet then displays that information to them.
*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using PetLibrary;

namespace WinUI
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void submitButton_Click(object sender, RoutedEventArgs e)
        {
            // Create Pet Object & Display Its Contents
            try
            {
                Pet pet = new Pet(petNameTextBox.Text, petTypeTextBox.Text, int.Parse(petAgeTextBox.Text));
                MessageBox.Show(pet.StringifyPet());
            }
            catch
            {
                MessageBox.Show("Something went wrong... Make sure the default text has been replaced and try again");
            }
        }

        private void exitButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}

﻿/**
* 11/20/2023
* CSC 253
* Max Cayton
* This program allows the user to search an MDF database file containing products for either a specific product number, or for product descriptions that contain specified text.
*/
using ProductLibrary;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            resultsListBox.Items.Clear();
        }

        private void numberSearchButton_Click(object sender, EventArgs e)
        {
            SetListBox(resultsListBox,ProductOperations.GetProductNumberResults(productNumberTextBox.Text));
        }

        private void descSearchButton_Click(object sender, EventArgs e)
        {
            SetListBox(resultsListBox, ProductOperations.GetProductDescResults(descTextBox.Text));
        }

        private void SetListBox(ListBox lb, List<Product> list)
        {
            lb.Items.Clear();
            foreach (Product pro in list)
            {
                lb.Items.Add($"Product Number: {pro.Product_Number} Product Desc: {pro.Description}");
            }
        }

        private void showAllButton_Click(object sender, EventArgs e)
        {
            ProductDataClassesDataContext dataContext = new ProductDataClassesDataContext();
            resultsListBox.Items.Clear();
            foreach (Product pro in dataContext.Products)
            {
                resultsListBox.Items.Add($"Product Number: {pro.Product_Number} Product Desc: {pro.Description}");
            }
        }
    }
}

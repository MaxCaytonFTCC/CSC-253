﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StringExtensionLibrary
{
    public static class Extensions
    {
        // Converts String to Array of Characters
        public static char[] ToCharacterArray(this string str)
        {
            char[] chars = new char[str.Length];
            int index = 0;
            foreach (char c in str)
            {
                chars[index] = c;
                index++;
            }
            
            return chars;
        }

        // Converts String to Array of Dates
        public static string[] ToDateArray(this string str)
        {
            if (str.Length != 10 || !str.Contains('/'))  return null;
            return str.Split('/');
        }
        
        // Converts String to Phone Number
        public static string ToPhoneNumber(this string str)
        {
            if (str.Length != 10) return "Invalid Phone Number";

            string phoneNumber = str;

            phoneNumber = phoneNumber.Insert(0,"(");
            phoneNumber = phoneNumber.Insert(4, ") ");
            phoneNumber = phoneNumber.Insert(9, "-");

            return phoneNumber;
        }

        // Converts String to Itself in Reverse
        public static string ToReverse(this string str)
        {
            string reverse = "";
            for (int i = str.Length; i > 0; i--)
            {
                reverse += str[i - 1];
            }
            return reverse;
        }

        // Gets the number of words in a String
        public static int GetWordCount(this string str)
        {
            if (str.Contains("\n")) return -1; // Newlines not supported

            int count = 0;
            int charIndex = 0;
            foreach (char c in str)
            {
                if ((c == ' ' && charIndex != 0 && str[charIndex-1] != ' ') || charIndex == str.Length-1)
                {
                    count++;
                }
                charIndex++;
            }
            return count;
        }

    }
}

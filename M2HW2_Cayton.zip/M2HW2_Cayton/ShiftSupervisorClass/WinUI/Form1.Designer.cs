﻿namespace WinUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.exitButton = new System.Windows.Forms.Button();
            this.inputGroupBox = new System.Windows.Forms.GroupBox();
            this.outputGroupBox = new System.Windows.Forms.GroupBox();
            this.inputInstructionLabel = new System.Windows.Forms.Label();
            this.outputLabel = new System.Windows.Forms.Label();
            this.inputNameTextBox = new System.Windows.Forms.TextBox();
            this.inputNumberTextBox = new System.Windows.Forms.TextBox();
            this.inputAnualSalaryTextBox = new System.Windows.Forms.TextBox();
            this.inputAnualProductionTextBox = new System.Windows.Forms.TextBox();
            this.outputAnualProductionTextBox = new System.Windows.Forms.TextBox();
            this.outputAnualSalaryTextBox = new System.Windows.Forms.TextBox();
            this.outputNumberTextBox = new System.Windows.Forms.TextBox();
            this.outputNameTextBox = new System.Windows.Forms.TextBox();
            this.submitButton = new System.Windows.Forms.Button();
            this.clearButton = new System.Windows.Forms.Button();
            this.displayButton = new System.Windows.Forms.Button();
            this.inputGroupBox.SuspendLayout();
            this.outputGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(579, 271);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(93, 36);
            this.exitButton.TabIndex = 0;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // inputGroupBox
            // 
            this.inputGroupBox.Controls.Add(this.submitButton);
            this.inputGroupBox.Controls.Add(this.inputAnualProductionTextBox);
            this.inputGroupBox.Controls.Add(this.inputAnualSalaryTextBox);
            this.inputGroupBox.Controls.Add(this.inputNumberTextBox);
            this.inputGroupBox.Controls.Add(this.inputNameTextBox);
            this.inputGroupBox.Controls.Add(this.inputInstructionLabel);
            this.inputGroupBox.Location = new System.Drawing.Point(12, 12);
            this.inputGroupBox.Name = "inputGroupBox";
            this.inputGroupBox.Size = new System.Drawing.Size(316, 253);
            this.inputGroupBox.TabIndex = 1;
            this.inputGroupBox.TabStop = false;
            this.inputGroupBox.Text = "Input";
            // 
            // outputGroupBox
            // 
            this.outputGroupBox.Controls.Add(this.displayButton);
            this.outputGroupBox.Controls.Add(this.clearButton);
            this.outputGroupBox.Controls.Add(this.outputAnualProductionTextBox);
            this.outputGroupBox.Controls.Add(this.outputLabel);
            this.outputGroupBox.Controls.Add(this.outputAnualSalaryTextBox);
            this.outputGroupBox.Controls.Add(this.outputNumberTextBox);
            this.outputGroupBox.Controls.Add(this.outputNameTextBox);
            this.outputGroupBox.Location = new System.Drawing.Point(389, 12);
            this.outputGroupBox.Name = "outputGroupBox";
            this.outputGroupBox.Size = new System.Drawing.Size(289, 253);
            this.outputGroupBox.TabIndex = 2;
            this.outputGroupBox.TabStop = false;
            this.outputGroupBox.Text = "Output";
            // 
            // inputInstructionLabel
            // 
            this.inputInstructionLabel.AutoSize = true;
            this.inputInstructionLabel.Location = new System.Drawing.Point(6, 43);
            this.inputInstructionLabel.Name = "inputInstructionLabel";
            this.inputInstructionLabel.Size = new System.Drawing.Size(134, 140);
            this.inputInstructionLabel.TabIndex = 0;
            this.inputInstructionLabel.Text = "Name:\r\n\r\nNumber:\r\n\r\nAnual Salary:\r\n\r\nAnual Production:";
            // 
            // outputLabel
            // 
            this.outputLabel.AutoSize = true;
            this.outputLabel.Location = new System.Drawing.Point(6, 43);
            this.outputLabel.Name = "outputLabel";
            this.outputLabel.Size = new System.Drawing.Size(134, 140);
            this.outputLabel.TabIndex = 1;
            this.outputLabel.Text = "Name:\r\n\r\nNumber:\r\n\r\nAnual Salary:\r\n\r\nAnual Production:";
            // 
            // inputNameTextBox
            // 
            this.inputNameTextBox.Location = new System.Drawing.Point(146, 43);
            this.inputNameTextBox.Name = "inputNameTextBox";
            this.inputNameTextBox.Size = new System.Drawing.Size(100, 26);
            this.inputNameTextBox.TabIndex = 1;
            // 
            // inputNumberTextBox
            // 
            this.inputNumberTextBox.Location = new System.Drawing.Point(147, 75);
            this.inputNumberTextBox.Name = "inputNumberTextBox";
            this.inputNumberTextBox.Size = new System.Drawing.Size(100, 26);
            this.inputNumberTextBox.TabIndex = 2;
            // 
            // inputAnualSalaryTextBox
            // 
            this.inputAnualSalaryTextBox.Location = new System.Drawing.Point(146, 125);
            this.inputAnualSalaryTextBox.Name = "inputAnualSalaryTextBox";
            this.inputAnualSalaryTextBox.Size = new System.Drawing.Size(100, 26);
            this.inputAnualSalaryTextBox.TabIndex = 3;
            // 
            // inputAnualProductionTextBox
            // 
            this.inputAnualProductionTextBox.Location = new System.Drawing.Point(147, 157);
            this.inputAnualProductionTextBox.Name = "inputAnualProductionTextBox";
            this.inputAnualProductionTextBox.Size = new System.Drawing.Size(100, 26);
            this.inputAnualProductionTextBox.TabIndex = 4;
            // 
            // outputAnualProductionTextBox
            // 
            this.outputAnualProductionTextBox.Location = new System.Drawing.Point(146, 157);
            this.outputAnualProductionTextBox.Name = "outputAnualProductionTextBox";
            this.outputAnualProductionTextBox.Size = new System.Drawing.Size(100, 26);
            this.outputAnualProductionTextBox.TabIndex = 8;
            // 
            // outputAnualSalaryTextBox
            // 
            this.outputAnualSalaryTextBox.Location = new System.Drawing.Point(145, 125);
            this.outputAnualSalaryTextBox.Name = "outputAnualSalaryTextBox";
            this.outputAnualSalaryTextBox.Size = new System.Drawing.Size(100, 26);
            this.outputAnualSalaryTextBox.TabIndex = 7;
            // 
            // outputNumberTextBox
            // 
            this.outputNumberTextBox.Location = new System.Drawing.Point(146, 75);
            this.outputNumberTextBox.Name = "outputNumberTextBox";
            this.outputNumberTextBox.Size = new System.Drawing.Size(100, 26);
            this.outputNumberTextBox.TabIndex = 6;
            // 
            // outputNameTextBox
            // 
            this.outputNameTextBox.Location = new System.Drawing.Point(145, 43);
            this.outputNameTextBox.Name = "outputNameTextBox";
            this.outputNameTextBox.Size = new System.Drawing.Size(100, 26);
            this.outputNameTextBox.TabIndex = 5;
            // 
            // submitButton
            // 
            this.submitButton.Location = new System.Drawing.Point(217, 212);
            this.submitButton.Name = "submitButton";
            this.submitButton.Size = new System.Drawing.Size(93, 35);
            this.submitButton.TabIndex = 5;
            this.submitButton.Text = "Submit";
            this.submitButton.UseVisualStyleBackColor = true;
            this.submitButton.Click += new System.EventHandler(this.submitButton_Click);
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(190, 212);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(93, 35);
            this.clearButton.TabIndex = 9;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // displayButton
            // 
            this.displayButton.Location = new System.Drawing.Point(6, 212);
            this.displayButton.Name = "displayButton";
            this.displayButton.Size = new System.Drawing.Size(86, 35);
            this.displayButton.TabIndex = 10;
            this.displayButton.Text = "Display";
            this.displayButton.UseVisualStyleBackColor = true;
            this.displayButton.Click += new System.EventHandler(this.displayButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(690, 319);
            this.Controls.Add(this.outputGroupBox);
            this.Controls.Add(this.inputGroupBox);
            this.Controls.Add(this.exitButton);
            this.Name = "Form1";
            this.Text = "Shift Supervisor Class";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.inputGroupBox.ResumeLayout(false);
            this.inputGroupBox.PerformLayout();
            this.outputGroupBox.ResumeLayout(false);
            this.outputGroupBox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.GroupBox inputGroupBox;
        private System.Windows.Forms.GroupBox outputGroupBox;
        private System.Windows.Forms.Label inputInstructionLabel;
        private System.Windows.Forms.TextBox inputAnualProductionTextBox;
        private System.Windows.Forms.TextBox inputAnualSalaryTextBox;
        private System.Windows.Forms.TextBox inputNumberTextBox;
        private System.Windows.Forms.TextBox inputNameTextBox;
        private System.Windows.Forms.TextBox outputAnualProductionTextBox;
        private System.Windows.Forms.Label outputLabel;
        private System.Windows.Forms.TextBox outputAnualSalaryTextBox;
        private System.Windows.Forms.TextBox outputNumberTextBox;
        private System.Windows.Forms.TextBox outputNameTextBox;
        private System.Windows.Forms.Button submitButton;
        private System.Windows.Forms.Button displayButton;
        private System.Windows.Forms.Button clearButton;
    }
}


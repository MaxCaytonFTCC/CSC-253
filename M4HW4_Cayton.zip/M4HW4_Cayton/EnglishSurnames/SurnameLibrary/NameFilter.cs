﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SurnameLibrary
{
    
    public static class NameFilter
    {
        public static List<string> GetNamesFromFile()
        {
            List<string> names = new List<string>();

            using (StreamReader reader = File.OpenText(@"../../../SurnameLibrary/surnames.txt"))
            {
                while (!reader.EndOfStream)
                {
                    names.Add(reader.ReadLine());
                }
            }
            return names;
        }

        // Longer-Than filter
        public static List<string> FilterNamesLongerThan(List<string> names,int criterion)
        {
            return names.FindAll(x => x.Length > criterion);
        }

        // Shorter-Than filter
        public static List<string> FilterNamesShorterThan(List<string> names, int criterion)
        {
            return names.FindAll(x => x.Length < criterion);
        }

        // Begins-With filter
        public static List<string> FilterNamesBeginsWith(List<string> names, string criterion)
        {
           
            Predicate<string> StartsWith = x =>
            {
                // Prevent Case Sensitivity
                x = x.ToLower();
                criterion = criterion.ToLower();   

                // Check Strings
                for (int i = 0; i < criterion.Length; i++)
                {
                    if (x[i] != criterion[i])
                    {
                        return false;
                    }
                }
                return true;
            };

            return names.FindAll(StartsWith);
        }

    }
}

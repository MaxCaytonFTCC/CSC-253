﻿namespace WinUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.exitButton = new System.Windows.Forms.Button();
            this.regularTextRichTextBox = new System.Windows.Forms.RichTextBox();
            this.openRegularTextButton = new System.Windows.Forms.Button();
            this.regularTextGroupBox = new System.Windows.Forms.GroupBox();
            this.writeButton = new System.Windows.Forms.Button();
            this.regularTextInstructionLabel = new System.Windows.Forms.Label();
            this.encryptedTextGroupBox = new System.Windows.Forms.GroupBox();
            this.encryptedRichTextBox = new System.Windows.Forms.RichTextBox();
            this.encryptionInstructionLabel = new System.Windows.Forms.Label();
            this.encryptButton = new System.Windows.Forms.Button();
            this.decryptionInstructionLabel = new System.Windows.Forms.Label();
            this.decryptButton = new System.Windows.Forms.Button();
            this.encryptedWriteButton = new System.Windows.Forms.Button();
            this.encryptedOpenButton = new System.Windows.Forms.Button();
            this.clearButton = new System.Windows.Forms.Button();
            this.regularTextGroupBox.SuspendLayout();
            this.encryptedTextGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(967, 1259);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(81, 40);
            this.exitButton.TabIndex = 0;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // regularTextRichTextBox
            // 
            this.regularTextRichTextBox.Location = new System.Drawing.Point(52, 79);
            this.regularTextRichTextBox.Name = "regularTextRichTextBox";
            this.regularTextRichTextBox.Size = new System.Drawing.Size(897, 366);
            this.regularTextRichTextBox.TabIndex = 1;
            this.regularTextRichTextBox.Text = "";
            // 
            // openRegularTextButton
            // 
            this.openRegularTextButton.Location = new System.Drawing.Point(52, 451);
            this.openRegularTextButton.Name = "openRegularTextButton";
            this.openRegularTextButton.Size = new System.Drawing.Size(90, 40);
            this.openRegularTextButton.TabIndex = 2;
            this.openRegularTextButton.Text = "Open";
            this.openRegularTextButton.UseVisualStyleBackColor = true;
            this.openRegularTextButton.Click += new System.EventHandler(this.openRegularTextButton_Click);
            // 
            // regularTextGroupBox
            // 
            this.regularTextGroupBox.Controls.Add(this.writeButton);
            this.regularTextGroupBox.Controls.Add(this.regularTextInstructionLabel);
            this.regularTextGroupBox.Controls.Add(this.regularTextRichTextBox);
            this.regularTextGroupBox.Controls.Add(this.openRegularTextButton);
            this.regularTextGroupBox.Location = new System.Drawing.Point(12, 12);
            this.regularTextGroupBox.Name = "regularTextGroupBox";
            this.regularTextGroupBox.Size = new System.Drawing.Size(1030, 552);
            this.regularTextGroupBox.TabIndex = 3;
            this.regularTextGroupBox.TabStop = false;
            this.regularTextGroupBox.Text = "Read And Edit Regular Text File";
            // 
            // writeButton
            // 
            this.writeButton.Location = new System.Drawing.Point(861, 451);
            this.writeButton.Name = "writeButton";
            this.writeButton.Size = new System.Drawing.Size(88, 40);
            this.writeButton.TabIndex = 4;
            this.writeButton.Text = "Write";
            this.writeButton.UseVisualStyleBackColor = true;
            this.writeButton.Click += new System.EventHandler(this.writeButton_Click);
            // 
            // regularTextInstructionLabel
            // 
            this.regularTextInstructionLabel.AutoSize = true;
            this.regularTextInstructionLabel.Location = new System.Drawing.Point(52, 53);
            this.regularTextInstructionLabel.Name = "regularTextInstructionLabel";
            this.regularTextInstructionLabel.Size = new System.Drawing.Size(686, 20);
            this.regularTextInstructionLabel.TabIndex = 3;
            this.regularTextInstructionLabel.Text = "Click \'Open\' to read contents of the unencrytped file, and click \'Write\' to save " +
    "changes made to it.";
            // 
            // encryptedTextGroupBox
            // 
            this.encryptedTextGroupBox.Controls.Add(this.encryptedOpenButton);
            this.encryptedTextGroupBox.Controls.Add(this.encryptedWriteButton);
            this.encryptedTextGroupBox.Controls.Add(this.encryptedRichTextBox);
            this.encryptedTextGroupBox.Location = new System.Drawing.Point(13, 668);
            this.encryptedTextGroupBox.Name = "encryptedTextGroupBox";
            this.encryptedTextGroupBox.Size = new System.Drawing.Size(1035, 489);
            this.encryptedTextGroupBox.TabIndex = 4;
            this.encryptedTextGroupBox.TabStop = false;
            this.encryptedTextGroupBox.Text = "View Encrypted Text File";
            // 
            // encryptedRichTextBox
            // 
            this.encryptedRichTextBox.Location = new System.Drawing.Point(55, 62);
            this.encryptedRichTextBox.Name = "encryptedRichTextBox";
            this.encryptedRichTextBox.Size = new System.Drawing.Size(893, 367);
            this.encryptedRichTextBox.TabIndex = 0;
            this.encryptedRichTextBox.Text = "";
            // 
            // encryptionInstructionLabel
            // 
            this.encryptionInstructionLabel.AutoSize = true;
            this.encryptionInstructionLabel.Location = new System.Drawing.Point(363, 585);
            this.encryptionInstructionLabel.Name = "encryptionInstructionLabel";
            this.encryptionInstructionLabel.Size = new System.Drawing.Size(284, 20);
            this.encryptionInstructionLabel.TabIndex = 1;
            this.encryptionInstructionLabel.Text = "Click \'Encrypt\' to encrypt the above text";
            // 
            // encryptButton
            // 
            this.encryptButton.Location = new System.Drawing.Point(456, 608);
            this.encryptButton.Name = "encryptButton";
            this.encryptButton.Size = new System.Drawing.Size(95, 39);
            this.encryptButton.TabIndex = 5;
            this.encryptButton.Text = "Encrypt";
            this.encryptButton.UseVisualStyleBackColor = true;
            this.encryptButton.Click += new System.EventHandler(this.encryptButton_Click);
            // 
            // decryptionInstructionLabel
            // 
            this.decryptionInstructionLabel.AutoSize = true;
            this.decryptionInstructionLabel.Location = new System.Drawing.Point(367, 1200);
            this.decryptionInstructionLabel.Name = "decryptionInstructionLabel";
            this.decryptionInstructionLabel.Size = new System.Drawing.Size(285, 20);
            this.decryptionInstructionLabel.TabIndex = 6;
            this.decryptionInstructionLabel.Text = "Click \'Decrypt\' to decrypt the above text";
            // 
            // decryptButton
            // 
            this.decryptButton.Location = new System.Drawing.Point(456, 1237);
            this.decryptButton.Name = "decryptButton";
            this.decryptButton.Size = new System.Drawing.Size(95, 38);
            this.decryptButton.TabIndex = 7;
            this.decryptButton.Text = "Decrypt";
            this.decryptButton.UseVisualStyleBackColor = true;
            this.decryptButton.Click += new System.EventHandler(this.decryptButton_Click);
            // 
            // encryptedWriteButton
            // 
            this.encryptedWriteButton.Location = new System.Drawing.Point(860, 432);
            this.encryptedWriteButton.Name = "encryptedWriteButton";
            this.encryptedWriteButton.Size = new System.Drawing.Size(88, 42);
            this.encryptedWriteButton.TabIndex = 8;
            this.encryptedWriteButton.Text = "Write";
            this.encryptedWriteButton.UseVisualStyleBackColor = true;
            this.encryptedWriteButton.Click += new System.EventHandler(this.encryptedWriteButton_Click);
            // 
            // encryptedOpenButton
            // 
            this.encryptedOpenButton.Location = new System.Drawing.Point(51, 432);
            this.encryptedOpenButton.Name = "encryptedOpenButton";
            this.encryptedOpenButton.Size = new System.Drawing.Size(90, 40);
            this.encryptedOpenButton.TabIndex = 5;
            this.encryptedOpenButton.Text = "Open";
            this.encryptedOpenButton.UseVisualStyleBackColor = true;
            this.encryptedOpenButton.Click += new System.EventHandler(this.encryptedOpenButton_Click);
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(12, 1259);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(75, 40);
            this.clearButton.TabIndex = 8;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // Form1
            // 
            this.AccessibleRole = System.Windows.Forms.AccessibleRole.Grip;
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1052, 1311);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.decryptButton);
            this.Controls.Add(this.decryptionInstructionLabel);
            this.Controls.Add(this.encryptButton);
            this.Controls.Add(this.encryptionInstructionLabel);
            this.Controls.Add(this.encryptedTextGroupBox);
            this.Controls.Add(this.regularTextGroupBox);
            this.Controls.Add(this.exitButton);
            this.Name = "Form1";
            this.Text = "File Encryption & Decryption";
            this.regularTextGroupBox.ResumeLayout(false);
            this.regularTextGroupBox.PerformLayout();
            this.encryptedTextGroupBox.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.RichTextBox regularTextRichTextBox;
        private System.Windows.Forms.Button openRegularTextButton;
        private System.Windows.Forms.GroupBox regularTextGroupBox;
        private System.Windows.Forms.Label regularTextInstructionLabel;
        private System.Windows.Forms.Button writeButton;
        private System.Windows.Forms.GroupBox encryptedTextGroupBox;
        private System.Windows.Forms.RichTextBox encryptedRichTextBox;
        private System.Windows.Forms.Label encryptionInstructionLabel;
        private System.Windows.Forms.Button encryptButton;
        private System.Windows.Forms.Label decryptionInstructionLabel;
        private System.Windows.Forms.Button decryptButton;
        private System.Windows.Forms.Button encryptedWriteButton;
        private System.Windows.Forms.Button encryptedOpenButton;
        private System.Windows.Forms.Button clearButton;
    }
}


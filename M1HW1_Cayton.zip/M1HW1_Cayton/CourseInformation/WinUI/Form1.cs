﻿/**
* 8/28/2023
* CSC 253
* Max Cayton
* This program takes the number ID of a course as input and outputs the course's room number, instructor name and meeting time.
*/
using System;
using CourseLibrary;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinUI
{
    public partial class Form1 : Form
    {
        
        public Form1()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
                     
            this.Close();
        }

        private void submitButton_Click(object sender, EventArgs e)
        {
            // Display Data
            try
            {
                roomNumberTextBox.Text = Course.courseRoomNumbers[courseNumberTextBox.Text];
                instructorTextBox.Text = Course.courseInstructorNames[courseNumberTextBox.Text];
                meetingTimeTextBox.Text = Course.courseMeetingTimes[courseNumberTextBox.Text];
            }
            catch
            {
                MessageBox.Show("Invalid Input. Try again.");
            }
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            // Clear Text Boxes
            courseNumberTextBox.Clear();
            roomNumberTextBox.Clear();
            instructorTextBox.Clear();
            meetingTimeTextBox.Clear();
        }
    }
}

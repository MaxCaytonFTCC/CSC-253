﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeLibrary
{
    public class Employee
    {
        public Employee() // Default Constructor
        {
            // Default Values
            Name = "NoName";
            Number = 0;
        } 

        public string Name { get; set; }
        public int Number { get; set; }

    }
}

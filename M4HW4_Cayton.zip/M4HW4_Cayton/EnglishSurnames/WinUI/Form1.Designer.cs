﻿namespace WinUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.namesListBox = new System.Windows.Forms.ListBox();
            this.exitButton = new System.Windows.Forms.Button();
            this.longerGroupBox = new System.Windows.Forms.GroupBox();
            this.shorterGroupBox = new System.Windows.Forms.GroupBox();
            this.beginWithGroupBox = new System.Windows.Forms.GroupBox();
            this.longerLabel = new System.Windows.Forms.Label();
            this.longerTextBox = new System.Windows.Forms.TextBox();
            this.longerButton = new System.Windows.Forms.Button();
            this.shorterButton = new System.Windows.Forms.Button();
            this.beginsButton = new System.Windows.Forms.Button();
            this.shorterLabel = new System.Windows.Forms.Label();
            this.shorterTextBox = new System.Windows.Forms.TextBox();
            this.beginsLabel = new System.Windows.Forms.Label();
            this.beginsTextBox = new System.Windows.Forms.TextBox();
            this.noteLabel = new System.Windows.Forms.Label();
            this.namesLabel = new System.Windows.Forms.Label();
            this.noFilterButton = new System.Windows.Forms.Button();
            this.longerGroupBox.SuspendLayout();
            this.shorterGroupBox.SuspendLayout();
            this.beginWithGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // namesListBox
            // 
            this.namesListBox.FormattingEnabled = true;
            this.namesListBox.ItemHeight = 20;
            this.namesListBox.Location = new System.Drawing.Point(559, 30);
            this.namesListBox.Name = "namesListBox";
            this.namesListBox.Size = new System.Drawing.Size(373, 684);
            this.namesListBox.TabIndex = 0;
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(857, 720);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 35);
            this.exitButton.TabIndex = 1;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // longerGroupBox
            // 
            this.longerGroupBox.Controls.Add(this.longerButton);
            this.longerGroupBox.Controls.Add(this.longerTextBox);
            this.longerGroupBox.Controls.Add(this.longerLabel);
            this.longerGroupBox.Location = new System.Drawing.Point(75, 83);
            this.longerGroupBox.Name = "longerGroupBox";
            this.longerGroupBox.Size = new System.Drawing.Size(426, 181);
            this.longerGroupBox.TabIndex = 2;
            this.longerGroupBox.TabStop = false;
            this.longerGroupBox.Text = "Longer Than...";
            // 
            // shorterGroupBox
            // 
            this.shorterGroupBox.Controls.Add(this.shorterTextBox);
            this.shorterGroupBox.Controls.Add(this.shorterLabel);
            this.shorterGroupBox.Controls.Add(this.shorterButton);
            this.shorterGroupBox.Location = new System.Drawing.Point(75, 270);
            this.shorterGroupBox.Name = "shorterGroupBox";
            this.shorterGroupBox.Size = new System.Drawing.Size(426, 165);
            this.shorterGroupBox.TabIndex = 3;
            this.shorterGroupBox.TabStop = false;
            this.shorterGroupBox.Text = "Shorter Than...";
            // 
            // beginWithGroupBox
            // 
            this.beginWithGroupBox.Controls.Add(this.beginsTextBox);
            this.beginWithGroupBox.Controls.Add(this.beginsLabel);
            this.beginWithGroupBox.Controls.Add(this.beginsButton);
            this.beginWithGroupBox.Location = new System.Drawing.Point(75, 441);
            this.beginWithGroupBox.Name = "beginWithGroupBox";
            this.beginWithGroupBox.Size = new System.Drawing.Size(426, 186);
            this.beginWithGroupBox.TabIndex = 4;
            this.beginWithGroupBox.TabStop = false;
            this.beginWithGroupBox.Text = "Begins With...";
            // 
            // longerLabel
            // 
            this.longerLabel.AutoSize = true;
            this.longerLabel.Location = new System.Drawing.Point(7, 38);
            this.longerLabel.Name = "longerLabel";
            this.longerLabel.Size = new System.Drawing.Size(382, 20);
            this.longerLabel.TabIndex = 0;
            this.longerLabel.Text = "Find all names longer than:                           characters\r\n";
            // 
            // longerTextBox
            // 
            this.longerTextBox.Location = new System.Drawing.Point(204, 35);
            this.longerTextBox.Name = "longerTextBox";
            this.longerTextBox.Size = new System.Drawing.Size(100, 26);
            this.longerTextBox.TabIndex = 1;
            // 
            // longerButton
            // 
            this.longerButton.Location = new System.Drawing.Point(320, 131);
            this.longerButton.Name = "longerButton";
            this.longerButton.Size = new System.Drawing.Size(100, 44);
            this.longerButton.TabIndex = 2;
            this.longerButton.Text = "Apply Filter";
            this.longerButton.UseVisualStyleBackColor = true;
            this.longerButton.Click += new System.EventHandler(this.longerButton_Click);
            // 
            // shorterButton
            // 
            this.shorterButton.Location = new System.Drawing.Point(320, 115);
            this.shorterButton.Name = "shorterButton";
            this.shorterButton.Size = new System.Drawing.Size(100, 44);
            this.shorterButton.TabIndex = 3;
            this.shorterButton.Text = "Apply Filter";
            this.shorterButton.UseVisualStyleBackColor = true;
            this.shorterButton.Click += new System.EventHandler(this.shorterButton_Click);
            // 
            // beginsButton
            // 
            this.beginsButton.Location = new System.Drawing.Point(320, 136);
            this.beginsButton.Name = "beginsButton";
            this.beginsButton.Size = new System.Drawing.Size(100, 44);
            this.beginsButton.TabIndex = 4;
            this.beginsButton.Text = "Apply Filter";
            this.beginsButton.UseVisualStyleBackColor = true;
            this.beginsButton.Click += new System.EventHandler(this.beginsButton_Click);
            // 
            // shorterLabel
            // 
            this.shorterLabel.AutoSize = true;
            this.shorterLabel.Location = new System.Drawing.Point(7, 35);
            this.shorterLabel.Name = "shorterLabel";
            this.shorterLabel.Size = new System.Drawing.Size(388, 20);
            this.shorterLabel.TabIndex = 3;
            this.shorterLabel.Text = "Find all names shorter than:                           characters\r\n";
            // 
            // shorterTextBox
            // 
            this.shorterTextBox.Location = new System.Drawing.Point(210, 32);
            this.shorterTextBox.Name = "shorterTextBox";
            this.shorterTextBox.Size = new System.Drawing.Size(100, 26);
            this.shorterTextBox.TabIndex = 3;
            // 
            // beginsLabel
            // 
            this.beginsLabel.AutoSize = true;
            this.beginsLabel.Location = new System.Drawing.Point(7, 44);
            this.beginsLabel.Name = "beginsLabel";
            this.beginsLabel.Size = new System.Drawing.Size(222, 20);
            this.beginsLabel.TabIndex = 4;
            this.beginsLabel.Text = "Find all names that begin with:";
            // 
            // beginsTextBox
            // 
            this.beginsTextBox.Location = new System.Drawing.Point(226, 41);
            this.beginsTextBox.Name = "beginsTextBox";
            this.beginsTextBox.Size = new System.Drawing.Size(100, 26);
            this.beginsTextBox.TabIndex = 4;
            // 
            // noteLabel
            // 
            this.noteLabel.AutoSize = true;
            this.noteLabel.Location = new System.Drawing.Point(120, 735);
            this.noteLabel.Name = "noteLabel";
            this.noteLabel.Size = new System.Drawing.Size(322, 20);
            this.noteLabel.TabIndex = 5;
            this.noteLabel.Text = "Note: Only one filter may be applied at a time";
            // 
            // namesLabel
            // 
            this.namesLabel.AutoSize = true;
            this.namesLabel.Location = new System.Drawing.Point(718, 7);
            this.namesLabel.Name = "namesLabel";
            this.namesLabel.Size = new System.Drawing.Size(59, 20);
            this.namesLabel.TabIndex = 6;
            this.namesLabel.Text = "Names";
            // 
            // noFilterButton
            // 
            this.noFilterButton.Location = new System.Drawing.Point(186, 663);
            this.noFilterButton.Name = "noFilterButton";
            this.noFilterButton.Size = new System.Drawing.Size(196, 39);
            this.noFilterButton.TabIndex = 7;
            this.noFilterButton.Text = "Show Without Filters";
            this.noFilterButton.UseVisualStyleBackColor = true;
            this.noFilterButton.Click += new System.EventHandler(this.noFilterButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(954, 767);
            this.Controls.Add(this.noFilterButton);
            this.Controls.Add(this.namesLabel);
            this.Controls.Add(this.noteLabel);
            this.Controls.Add(this.beginWithGroupBox);
            this.Controls.Add(this.shorterGroupBox);
            this.Controls.Add(this.longerGroupBox);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.namesListBox);
            this.Name = "Form1";
            this.Text = "English Surnames";
            this.longerGroupBox.ResumeLayout(false);
            this.longerGroupBox.PerformLayout();
            this.shorterGroupBox.ResumeLayout(false);
            this.shorterGroupBox.PerformLayout();
            this.beginWithGroupBox.ResumeLayout(false);
            this.beginWithGroupBox.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox namesListBox;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.GroupBox longerGroupBox;
        private System.Windows.Forms.GroupBox shorterGroupBox;
        private System.Windows.Forms.Button longerButton;
        private System.Windows.Forms.TextBox longerTextBox;
        private System.Windows.Forms.Label longerLabel;
        private System.Windows.Forms.Button shorterButton;
        private System.Windows.Forms.GroupBox beginWithGroupBox;
        private System.Windows.Forms.Button beginsButton;
        private System.Windows.Forms.TextBox shorterTextBox;
        private System.Windows.Forms.Label shorterLabel;
        private System.Windows.Forms.TextBox beginsTextBox;
        private System.Windows.Forms.Label beginsLabel;
        private System.Windows.Forms.Label noteLabel;
        private System.Windows.Forms.Label namesLabel;
        private System.Windows.Forms.Button noFilterButton;
    }
}


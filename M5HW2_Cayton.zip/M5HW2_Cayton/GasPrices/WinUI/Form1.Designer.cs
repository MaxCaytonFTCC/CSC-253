﻿namespace WinUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.exitButton = new System.Windows.Forms.Button();
            this.avgPricePerYearGroupBox = new System.Windows.Forms.GroupBox();
            this.displayYearLabel = new System.Windows.Forms.Label();
            this.displayYearButton = new System.Windows.Forms.Button();
            this.yearTextBox = new System.Windows.Forms.TextBox();
            this.avgPricePerMonthGroupBox = new System.Windows.Forms.GroupBox();
            this.displayMonthButton = new System.Windows.Forms.Button();
            this.displayYearMonthLabel = new System.Windows.Forms.Label();
            this.monthYearTextBox = new System.Windows.Forms.TextBox();
            this.displayMonthLabel = new System.Windows.Forms.Label();
            this.monthTextBox = new System.Windows.Forms.TextBox();
            this.extremaGroupBox = new System.Windows.Forms.GroupBox();
            this.outputFileGroupBox = new System.Windows.Forms.GroupBox();
            this.highestButton = new System.Windows.Forms.Button();
            this.lowestButton = new System.Windows.Forms.Button();
            this.locationLabel = new System.Windows.Forms.Label();
            this.ascendingButton = new System.Windows.Forms.Button();
            this.descendingButton = new System.Windows.Forms.Button();
            this.avgPricePerYearGroupBox.SuspendLayout();
            this.avgPricePerMonthGroupBox.SuspendLayout();
            this.extremaGroupBox.SuspendLayout();
            this.outputFileGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(747, 595);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(86, 44);
            this.exitButton.TabIndex = 0;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // avgPricePerYearGroupBox
            // 
            this.avgPricePerYearGroupBox.Controls.Add(this.displayYearLabel);
            this.avgPricePerYearGroupBox.Controls.Add(this.displayYearButton);
            this.avgPricePerYearGroupBox.Controls.Add(this.yearTextBox);
            this.avgPricePerYearGroupBox.Location = new System.Drawing.Point(12, 12);
            this.avgPricePerYearGroupBox.Name = "avgPricePerYearGroupBox";
            this.avgPricePerYearGroupBox.Size = new System.Drawing.Size(437, 299);
            this.avgPricePerYearGroupBox.TabIndex = 1;
            this.avgPricePerYearGroupBox.TabStop = false;
            this.avgPricePerYearGroupBox.Text = "Display Average Price Per Given Year";
            // 
            // displayYearLabel
            // 
            this.displayYearLabel.AutoSize = true;
            this.displayYearLabel.Location = new System.Drawing.Point(42, 92);
            this.displayYearLabel.Name = "displayYearLabel";
            this.displayYearLabel.Size = new System.Drawing.Size(132, 20);
            this.displayYearLabel.TabIndex = 2;
            this.displayYearLabel.Text = "Enter target year:";
            // 
            // displayYearButton
            // 
            this.displayYearButton.Location = new System.Drawing.Point(45, 146);
            this.displayYearButton.Name = "displayYearButton";
            this.displayYearButton.Size = new System.Drawing.Size(218, 47);
            this.displayYearButton.TabIndex = 1;
            this.displayYearButton.Text = "Display Average For Year";
            this.displayYearButton.UseVisualStyleBackColor = true;
            this.displayYearButton.Click += new System.EventHandler(this.displayYearButton_Click);
            // 
            // yearTextBox
            // 
            this.yearTextBox.Location = new System.Drawing.Point(180, 92);
            this.yearTextBox.Name = "yearTextBox";
            this.yearTextBox.Size = new System.Drawing.Size(100, 26);
            this.yearTextBox.TabIndex = 0;
            // 
            // avgPricePerMonthGroupBox
            // 
            this.avgPricePerMonthGroupBox.Controls.Add(this.displayMonthButton);
            this.avgPricePerMonthGroupBox.Controls.Add(this.displayYearMonthLabel);
            this.avgPricePerMonthGroupBox.Controls.Add(this.monthYearTextBox);
            this.avgPricePerMonthGroupBox.Controls.Add(this.displayMonthLabel);
            this.avgPricePerMonthGroupBox.Controls.Add(this.monthTextBox);
            this.avgPricePerMonthGroupBox.Location = new System.Drawing.Point(22, 317);
            this.avgPricePerMonthGroupBox.Name = "avgPricePerMonthGroupBox";
            this.avgPricePerMonthGroupBox.Size = new System.Drawing.Size(427, 261);
            this.avgPricePerMonthGroupBox.TabIndex = 2;
            this.avgPricePerMonthGroupBox.TabStop = false;
            this.avgPricePerMonthGroupBox.Text = "Display Average Price Per Given Month";
            // 
            // displayMonthButton
            // 
            this.displayMonthButton.Location = new System.Drawing.Point(35, 175);
            this.displayMonthButton.Name = "displayMonthButton";
            this.displayMonthButton.Size = new System.Drawing.Size(218, 47);
            this.displayMonthButton.TabIndex = 3;
            this.displayMonthButton.Text = "Display Average For Year";
            this.displayMonthButton.UseVisualStyleBackColor = true;
            this.displayMonthButton.Click += new System.EventHandler(this.displayMonthButton_Click);
            // 
            // displayYearMonthLabel
            // 
            this.displayYearMonthLabel.AutoSize = true;
            this.displayYearMonthLabel.Location = new System.Drawing.Point(31, 72);
            this.displayYearMonthLabel.Name = "displayYearMonthLabel";
            this.displayYearMonthLabel.Size = new System.Drawing.Size(202, 20);
            this.displayYearMonthLabel.TabIndex = 6;
            this.displayYearMonthLabel.Text = "Enter target year (optional):";
            // 
            // monthYearTextBox
            // 
            this.monthYearTextBox.Location = new System.Drawing.Point(240, 72);
            this.monthYearTextBox.Name = "monthYearTextBox";
            this.monthYearTextBox.Size = new System.Drawing.Size(100, 26);
            this.monthYearTextBox.TabIndex = 5;
            // 
            // displayMonthLabel
            // 
            this.displayMonthLabel.AutoSize = true;
            this.displayMonthLabel.Location = new System.Drawing.Point(31, 118);
            this.displayMonthLabel.Name = "displayMonthLabel";
            this.displayMonthLabel.Size = new System.Drawing.Size(147, 20);
            this.displayMonthLabel.TabIndex = 4;
            this.displayMonthLabel.Text = "Enter target month:";
            // 
            // monthTextBox
            // 
            this.monthTextBox.Location = new System.Drawing.Point(184, 118);
            this.monthTextBox.Name = "monthTextBox";
            this.monthTextBox.Size = new System.Drawing.Size(100, 26);
            this.monthTextBox.TabIndex = 3;
            // 
            // extremaGroupBox
            // 
            this.extremaGroupBox.Controls.Add(this.lowestButton);
            this.extremaGroupBox.Controls.Add(this.highestButton);
            this.extremaGroupBox.Location = new System.Drawing.Point(473, 12);
            this.extremaGroupBox.Name = "extremaGroupBox";
            this.extremaGroupBox.Size = new System.Drawing.Size(360, 240);
            this.extremaGroupBox.TabIndex = 3;
            this.extremaGroupBox.TabStop = false;
            this.extremaGroupBox.Text = "Display Highest or Lowest Price";
            // 
            // outputFileGroupBox
            // 
            this.outputFileGroupBox.Controls.Add(this.descendingButton);
            this.outputFileGroupBox.Controls.Add(this.ascendingButton);
            this.outputFileGroupBox.Controls.Add(this.locationLabel);
            this.outputFileGroupBox.Location = new System.Drawing.Point(473, 258);
            this.outputFileGroupBox.Name = "outputFileGroupBox";
            this.outputFileGroupBox.Size = new System.Drawing.Size(360, 320);
            this.outputFileGroupBox.TabIndex = 4;
            this.outputFileGroupBox.TabStop = false;
            this.outputFileGroupBox.Text = "Create Output Files";
            // 
            // highestButton
            // 
            this.highestButton.Location = new System.Drawing.Point(77, 48);
            this.highestButton.Name = "highestButton";
            this.highestButton.Size = new System.Drawing.Size(199, 39);
            this.highestButton.TabIndex = 0;
            this.highestButton.Text = "Display Highest Price";
            this.highestButton.UseVisualStyleBackColor = true;
            this.highestButton.Click += new System.EventHandler(this.highestButton_Click);
            // 
            // lowestButton
            // 
            this.lowestButton.Location = new System.Drawing.Point(77, 117);
            this.lowestButton.Name = "lowestButton";
            this.lowestButton.Size = new System.Drawing.Size(199, 39);
            this.lowestButton.TabIndex = 1;
            this.lowestButton.Text = "Display Lowest Price";
            this.lowestButton.UseVisualStyleBackColor = true;
            this.lowestButton.Click += new System.EventHandler(this.lowestButton_Click);
            // 
            // locationLabel
            // 
            this.locationLabel.AutoSize = true;
            this.locationLabel.Location = new System.Drawing.Point(73, 263);
            this.locationLabel.Name = "locationLabel";
            this.locationLabel.Size = new System.Drawing.Size(224, 40);
            this.locationLabel.TabIndex = 0;
            this.locationLabel.Text = "Files located under \r\n\"..\\..\\..\\GasLibrary\\OutputFiles\\\"\r\n";
            this.locationLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // ascendingButton
            // 
            this.ascendingButton.Location = new System.Drawing.Point(50, 59);
            this.ascendingButton.Name = "ascendingButton";
            this.ascendingButton.Size = new System.Drawing.Size(258, 63);
            this.ascendingButton.TabIndex = 1;
            this.ascendingButton.Text = "Generate Ascending Order File";
            this.ascendingButton.UseVisualStyleBackColor = true;
            this.ascendingButton.Click += new System.EventHandler(this.ascendingButton_Click);
            // 
            // descendingButton
            // 
            this.descendingButton.Location = new System.Drawing.Point(50, 156);
            this.descendingButton.Name = "descendingButton";
            this.descendingButton.Size = new System.Drawing.Size(258, 63);
            this.descendingButton.TabIndex = 2;
            this.descendingButton.Text = "Generate Descending Order File";
            this.descendingButton.UseVisualStyleBackColor = true;
            this.descendingButton.Click += new System.EventHandler(this.descendingButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(847, 659);
            this.Controls.Add(this.outputFileGroupBox);
            this.Controls.Add(this.extremaGroupBox);
            this.Controls.Add(this.avgPricePerMonthGroupBox);
            this.Controls.Add(this.avgPricePerYearGroupBox);
            this.Controls.Add(this.exitButton);
            this.Name = "Form1";
            this.Text = "Gas Prices";
            this.avgPricePerYearGroupBox.ResumeLayout(false);
            this.avgPricePerYearGroupBox.PerformLayout();
            this.avgPricePerMonthGroupBox.ResumeLayout(false);
            this.avgPricePerMonthGroupBox.PerformLayout();
            this.extremaGroupBox.ResumeLayout(false);
            this.outputFileGroupBox.ResumeLayout(false);
            this.outputFileGroupBox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.GroupBox avgPricePerYearGroupBox;
        private System.Windows.Forms.GroupBox avgPricePerMonthGroupBox;
        private System.Windows.Forms.GroupBox extremaGroupBox;
        private System.Windows.Forms.Label displayYearLabel;
        private System.Windows.Forms.Button displayYearButton;
        private System.Windows.Forms.TextBox yearTextBox;
        private System.Windows.Forms.GroupBox outputFileGroupBox;
        private System.Windows.Forms.Label displayYearMonthLabel;
        private System.Windows.Forms.TextBox monthYearTextBox;
        private System.Windows.Forms.Label displayMonthLabel;
        private System.Windows.Forms.TextBox monthTextBox;
        private System.Windows.Forms.Button displayMonthButton;
        private System.Windows.Forms.Button lowestButton;
        private System.Windows.Forms.Button highestButton;
        private System.Windows.Forms.Label locationLabel;
        private System.Windows.Forms.Button descendingButton;
        private System.Windows.Forms.Button ascendingButton;
    }
}


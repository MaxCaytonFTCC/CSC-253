﻿namespace WinUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.resultsListBox = new System.Windows.Forms.ListBox();
            this.clearButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.productNumberTextBox = new System.Windows.Forms.TextBox();
            this.numberGroupBox = new System.Windows.Forms.GroupBox();
            this.noteLabel = new System.Windows.Forms.Label();
            this.numberSearchButton = new System.Windows.Forms.Button();
            this.descGroupBox = new System.Windows.Forms.GroupBox();
            this.descSearchButton = new System.Windows.Forms.Button();
            this.descTextBox = new System.Windows.Forms.TextBox();
            this.resultsLabel = new System.Windows.Forms.Label();
            this.showAllButton = new System.Windows.Forms.Button();
            this.filterNoteLabel = new System.Windows.Forms.Label();
            this.priceRangeGroupBox = new System.Windows.Forms.GroupBox();
            this.rangeLabel = new System.Windows.Forms.Label();
            this.priceMinTextBox = new System.Windows.Forms.TextBox();
            this.priceMaxTextBox = new System.Windows.Forms.TextBox();
            this.priceSearchButton = new System.Windows.Forms.Button();
            this.numberGroupBox.SuspendLayout();
            this.descGroupBox.SuspendLayout();
            this.priceRangeGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // resultsListBox
            // 
            this.resultsListBox.FormattingEnabled = true;
            this.resultsListBox.ItemHeight = 20;
            this.resultsListBox.Location = new System.Drawing.Point(560, 62);
            this.resultsListBox.Name = "resultsListBox";
            this.resultsListBox.Size = new System.Drawing.Size(642, 484);
            this.resultsListBox.TabIndex = 0;
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(759, 552);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(85, 39);
            this.clearButton.TabIndex = 1;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(1117, 552);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(85, 39);
            this.exitButton.TabIndex = 2;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // productNumberTextBox
            // 
            this.productNumberTextBox.Location = new System.Drawing.Point(100, 46);
            this.productNumberTextBox.Name = "productNumberTextBox";
            this.productNumberTextBox.Size = new System.Drawing.Size(164, 26);
            this.productNumberTextBox.TabIndex = 4;
            // 
            // numberGroupBox
            // 
            this.numberGroupBox.Controls.Add(this.noteLabel);
            this.numberGroupBox.Controls.Add(this.numberSearchButton);
            this.numberGroupBox.Controls.Add(this.productNumberTextBox);
            this.numberGroupBox.Location = new System.Drawing.Point(72, 12);
            this.numberGroupBox.Name = "numberGroupBox";
            this.numberGroupBox.Size = new System.Drawing.Size(376, 186);
            this.numberGroupBox.TabIndex = 5;
            this.numberGroupBox.TabStop = false;
            this.numberGroupBox.Text = "Search by Product Number";
            // 
            // noteLabel
            // 
            this.noteLabel.AutoSize = true;
            this.noteLabel.Location = new System.Drawing.Point(19, 143);
            this.noteLabel.Name = "noteLabel";
            this.noteLabel.Size = new System.Drawing.Size(340, 40);
            this.noteLabel.TabIndex = 6;
            this.noteLabel.Text = "Note: Product Numbers are formatted as ##-##\r\nEx: 10-01";
            // 
            // numberSearchButton
            // 
            this.numberSearchButton.Location = new System.Drawing.Point(137, 78);
            this.numberSearchButton.Name = "numberSearchButton";
            this.numberSearchButton.Size = new System.Drawing.Size(88, 38);
            this.numberSearchButton.TabIndex = 5;
            this.numberSearchButton.Text = "Search";
            this.numberSearchButton.UseVisualStyleBackColor = true;
            this.numberSearchButton.Click += new System.EventHandler(this.numberSearchButton_Click);
            // 
            // descGroupBox
            // 
            this.descGroupBox.Controls.Add(this.descSearchButton);
            this.descGroupBox.Controls.Add(this.descTextBox);
            this.descGroupBox.Location = new System.Drawing.Point(72, 226);
            this.descGroupBox.Name = "descGroupBox";
            this.descGroupBox.Size = new System.Drawing.Size(376, 143);
            this.descGroupBox.TabIndex = 6;
            this.descGroupBox.TabStop = false;
            this.descGroupBox.Text = "Search by Description";
            // 
            // descSearchButton
            // 
            this.descSearchButton.Location = new System.Drawing.Point(137, 80);
            this.descSearchButton.Name = "descSearchButton";
            this.descSearchButton.Size = new System.Drawing.Size(88, 38);
            this.descSearchButton.TabIndex = 5;
            this.descSearchButton.Text = "Search";
            this.descSearchButton.UseVisualStyleBackColor = true;
            this.descSearchButton.Click += new System.EventHandler(this.descSearchButton_Click);
            // 
            // descTextBox
            // 
            this.descTextBox.Location = new System.Drawing.Point(100, 48);
            this.descTextBox.Name = "descTextBox";
            this.descTextBox.Size = new System.Drawing.Size(164, 26);
            this.descTextBox.TabIndex = 4;
            // 
            // resultsLabel
            // 
            this.resultsLabel.AutoSize = true;
            this.resultsLabel.Location = new System.Drawing.Point(861, 39);
            this.resultsLabel.Name = "resultsLabel";
            this.resultsLabel.Size = new System.Drawing.Size(63, 20);
            this.resultsLabel.TabIndex = 7;
            this.resultsLabel.Text = "Results";
            // 
            // showAllButton
            // 
            this.showAllButton.Location = new System.Drawing.Point(560, 553);
            this.showAllButton.Name = "showAllButton";
            this.showAllButton.Size = new System.Drawing.Size(193, 39);
            this.showAllButton.TabIndex = 8;
            this.showAllButton.Text = "Show Without Filters";
            this.showAllButton.UseVisualStyleBackColor = true;
            this.showAllButton.Click += new System.EventHandler(this.showAllButton_Click);
            // 
            // filterNoteLabel
            // 
            this.filterNoteLabel.AutoSize = true;
            this.filterNoteLabel.Location = new System.Drawing.Point(109, 572);
            this.filterNoteLabel.Name = "filterNoteLabel";
            this.filterNoteLabel.Size = new System.Drawing.Size(322, 20);
            this.filterNoteLabel.TabIndex = 7;
            this.filterNoteLabel.Text = "Note: Only one filter may be applied at a time";
            // 
            // priceRangeGroupBox
            // 
            this.priceRangeGroupBox.Controls.Add(this.priceSearchButton);
            this.priceRangeGroupBox.Controls.Add(this.priceMaxTextBox);
            this.priceRangeGroupBox.Controls.Add(this.priceMinTextBox);
            this.priceRangeGroupBox.Controls.Add(this.rangeLabel);
            this.priceRangeGroupBox.Location = new System.Drawing.Point(72, 393);
            this.priceRangeGroupBox.Name = "priceRangeGroupBox";
            this.priceRangeGroupBox.Size = new System.Drawing.Size(376, 136);
            this.priceRangeGroupBox.TabIndex = 9;
            this.priceRangeGroupBox.TabStop = false;
            this.priceRangeGroupBox.Text = "Search by Price Range";
            // 
            // rangeLabel
            // 
            this.rangeLabel.AutoSize = true;
            this.rangeLabel.Location = new System.Drawing.Point(170, 55);
            this.rangeLabel.Name = "rangeLabel";
            this.rangeLabel.Size = new System.Drawing.Size(23, 20);
            this.rangeLabel.TabIndex = 0;
            this.rangeLabel.Text = "to";
            // 
            // priceMinTextBox
            // 
            this.priceMinTextBox.Location = new System.Drawing.Point(64, 55);
            this.priceMinTextBox.Name = "priceMinTextBox";
            this.priceMinTextBox.Size = new System.Drawing.Size(100, 26);
            this.priceMinTextBox.TabIndex = 1;
            // 
            // priceMaxTextBox
            // 
            this.priceMaxTextBox.Location = new System.Drawing.Point(199, 55);
            this.priceMaxTextBox.Name = "priceMaxTextBox";
            this.priceMaxTextBox.Size = new System.Drawing.Size(100, 26);
            this.priceMaxTextBox.TabIndex = 2;
            // 
            // priceSearchButton
            // 
            this.priceSearchButton.Location = new System.Drawing.Point(137, 92);
            this.priceSearchButton.Name = "priceSearchButton";
            this.priceSearchButton.Size = new System.Drawing.Size(88, 38);
            this.priceSearchButton.TabIndex = 6;
            this.priceSearchButton.Text = "Search";
            this.priceSearchButton.UseVisualStyleBackColor = true;
            this.priceSearchButton.Click += new System.EventHandler(this.priceSearchButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1214, 624);
            this.Controls.Add(this.priceRangeGroupBox);
            this.Controls.Add(this.filterNoteLabel);
            this.Controls.Add(this.showAllButton);
            this.Controls.Add(this.resultsLabel);
            this.Controls.Add(this.descGroupBox);
            this.Controls.Add(this.numberGroupBox);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.resultsListBox);
            this.Name = "Form1";
            this.Text = "Product Price Search";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.numberGroupBox.ResumeLayout(false);
            this.numberGroupBox.PerformLayout();
            this.descGroupBox.ResumeLayout(false);
            this.descGroupBox.PerformLayout();
            this.priceRangeGroupBox.ResumeLayout(false);
            this.priceRangeGroupBox.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox resultsListBox;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.TextBox productNumberTextBox;
        private System.Windows.Forms.GroupBox numberGroupBox;
        private System.Windows.Forms.Button numberSearchButton;
        private System.Windows.Forms.GroupBox descGroupBox;
        private System.Windows.Forms.Button descSearchButton;
        private System.Windows.Forms.TextBox descTextBox;
        private System.Windows.Forms.Label resultsLabel;
        private System.Windows.Forms.Label noteLabel;
        private System.Windows.Forms.Button showAllButton;
        private System.Windows.Forms.Label filterNoteLabel;
        private System.Windows.Forms.GroupBox priceRangeGroupBox;
        private System.Windows.Forms.Button priceSearchButton;
        private System.Windows.Forms.TextBox priceMaxTextBox;
        private System.Windows.Forms.TextBox priceMinTextBox;
        private System.Windows.Forms.Label rangeLabel;
    }
}


﻿namespace WinUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.resultsListBox = new System.Windows.Forms.ListBox();
            this.clearButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.productNumberTextBox = new System.Windows.Forms.TextBox();
            this.numberGroupBox = new System.Windows.Forms.GroupBox();
            this.noteLabel = new System.Windows.Forms.Label();
            this.numberSearchButton = new System.Windows.Forms.Button();
            this.descGroupBox = new System.Windows.Forms.GroupBox();
            this.descSearchButton = new System.Windows.Forms.Button();
            this.descTextBox = new System.Windows.Forms.TextBox();
            this.resultsLabel = new System.Windows.Forms.Label();
            this.showAllButton = new System.Windows.Forms.Button();
            this.filterNoteLabel = new System.Windows.Forms.Label();
            this.numberGroupBox.SuspendLayout();
            this.descGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // resultsListBox
            // 
            this.resultsListBox.FormattingEnabled = true;
            this.resultsListBox.ItemHeight = 20;
            this.resultsListBox.Location = new System.Drawing.Point(622, 62);
            this.resultsListBox.Name = "resultsListBox";
            this.resultsListBox.Size = new System.Drawing.Size(565, 484);
            this.resultsListBox.TabIndex = 0;
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(821, 552);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(85, 39);
            this.clearButton.TabIndex = 1;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(1102, 553);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(85, 39);
            this.exitButton.TabIndex = 2;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // productNumberTextBox
            // 
            this.productNumberTextBox.Location = new System.Drawing.Point(100, 46);
            this.productNumberTextBox.Name = "productNumberTextBox";
            this.productNumberTextBox.Size = new System.Drawing.Size(164, 26);
            this.productNumberTextBox.TabIndex = 4;
            // 
            // numberGroupBox
            // 
            this.numberGroupBox.Controls.Add(this.noteLabel);
            this.numberGroupBox.Controls.Add(this.numberSearchButton);
            this.numberGroupBox.Controls.Add(this.productNumberTextBox);
            this.numberGroupBox.Location = new System.Drawing.Point(72, 12);
            this.numberGroupBox.Name = "numberGroupBox";
            this.numberGroupBox.Size = new System.Drawing.Size(376, 186);
            this.numberGroupBox.TabIndex = 5;
            this.numberGroupBox.TabStop = false;
            this.numberGroupBox.Text = "Search by Product Number";
            // 
            // noteLabel
            // 
            this.noteLabel.AutoSize = true;
            this.noteLabel.Location = new System.Drawing.Point(19, 143);
            this.noteLabel.Name = "noteLabel";
            this.noteLabel.Size = new System.Drawing.Size(340, 40);
            this.noteLabel.TabIndex = 6;
            this.noteLabel.Text = "Note: Product Numbers are formatted as ##-##\r\nEx: 10-01";
            // 
            // numberSearchButton
            // 
            this.numberSearchButton.Location = new System.Drawing.Point(137, 78);
            this.numberSearchButton.Name = "numberSearchButton";
            this.numberSearchButton.Size = new System.Drawing.Size(88, 38);
            this.numberSearchButton.TabIndex = 5;
            this.numberSearchButton.Text = "Search";
            this.numberSearchButton.UseVisualStyleBackColor = true;
            this.numberSearchButton.Click += new System.EventHandler(this.numberSearchButton_Click);
            // 
            // descGroupBox
            // 
            this.descGroupBox.Controls.Add(this.descSearchButton);
            this.descGroupBox.Controls.Add(this.descTextBox);
            this.descGroupBox.Location = new System.Drawing.Point(72, 226);
            this.descGroupBox.Name = "descGroupBox";
            this.descGroupBox.Size = new System.Drawing.Size(376, 143);
            this.descGroupBox.TabIndex = 6;
            this.descGroupBox.TabStop = false;
            this.descGroupBox.Text = "Search by Description";
            // 
            // descSearchButton
            // 
            this.descSearchButton.Location = new System.Drawing.Point(137, 80);
            this.descSearchButton.Name = "descSearchButton";
            this.descSearchButton.Size = new System.Drawing.Size(88, 38);
            this.descSearchButton.TabIndex = 5;
            this.descSearchButton.Text = "Search";
            this.descSearchButton.UseVisualStyleBackColor = true;
            this.descSearchButton.Click += new System.EventHandler(this.descSearchButton_Click);
            // 
            // descTextBox
            // 
            this.descTextBox.Location = new System.Drawing.Point(100, 48);
            this.descTextBox.Name = "descTextBox";
            this.descTextBox.Size = new System.Drawing.Size(164, 26);
            this.descTextBox.TabIndex = 4;
            // 
            // resultsLabel
            // 
            this.resultsLabel.AutoSize = true;
            this.resultsLabel.Location = new System.Drawing.Point(871, 39);
            this.resultsLabel.Name = "resultsLabel";
            this.resultsLabel.Size = new System.Drawing.Size(63, 20);
            this.resultsLabel.TabIndex = 7;
            this.resultsLabel.Text = "Results";
            // 
            // showAllButton
            // 
            this.showAllButton.Location = new System.Drawing.Point(622, 553);
            this.showAllButton.Name = "showAllButton";
            this.showAllButton.Size = new System.Drawing.Size(193, 39);
            this.showAllButton.TabIndex = 8;
            this.showAllButton.Text = "Show Without Filters";
            this.showAllButton.UseVisualStyleBackColor = true;
            this.showAllButton.Click += new System.EventHandler(this.showAllButton_Click);
            // 
            // filterNoteLabel
            // 
            this.filterNoteLabel.AutoSize = true;
            this.filterNoteLabel.Location = new System.Drawing.Point(100, 482);
            this.filterNoteLabel.Name = "filterNoteLabel";
            this.filterNoteLabel.Size = new System.Drawing.Size(322, 20);
            this.filterNoteLabel.TabIndex = 7;
            this.filterNoteLabel.Text = "Note: Only one filter may be applied at a time";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1214, 624);
            this.Controls.Add(this.filterNoteLabel);
            this.Controls.Add(this.showAllButton);
            this.Controls.Add(this.resultsLabel);
            this.Controls.Add(this.descGroupBox);
            this.Controls.Add(this.numberGroupBox);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.resultsListBox);
            this.Name = "Form1";
            this.Text = "Product Search";
            this.numberGroupBox.ResumeLayout(false);
            this.numberGroupBox.PerformLayout();
            this.descGroupBox.ResumeLayout(false);
            this.descGroupBox.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox resultsListBox;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.TextBox productNumberTextBox;
        private System.Windows.Forms.GroupBox numberGroupBox;
        private System.Windows.Forms.Button numberSearchButton;
        private System.Windows.Forms.GroupBox descGroupBox;
        private System.Windows.Forms.Button descSearchButton;
        private System.Windows.Forms.TextBox descTextBox;
        private System.Windows.Forms.Label resultsLabel;
        private System.Windows.Forms.Label noteLabel;
        private System.Windows.Forms.Button showAllButton;
        private System.Windows.Forms.Label filterNoteLabel;
    }
}


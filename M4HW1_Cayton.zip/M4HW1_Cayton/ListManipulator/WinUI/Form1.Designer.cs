﻿namespace WinUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.randomListBox = new System.Windows.Forms.ListBox();
            this.randomLabel = new System.Windows.Forms.Label();
            this.reloadButton = new System.Windows.Forms.Button();
            this.inputGroupBox = new System.Windows.Forms.GroupBox();
            this.outputGroupBox = new System.Windows.Forms.GroupBox();
            this.outputListBox = new System.Windows.Forms.ListBox();
            this.exitButton = new System.Windows.Forms.Button();
            this.resultsLabel = new System.Windows.Forms.Label();
            this.removeNegativesButton = new System.Windows.Forms.Button();
            this.rangeButton = new System.Windows.Forms.Button();
            this.inputGroupBox.SuspendLayout();
            this.outputGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // randomListBox
            // 
            this.randomListBox.FormattingEnabled = true;
            this.randomListBox.ItemHeight = 20;
            this.randomListBox.Location = new System.Drawing.Point(62, 77);
            this.randomListBox.Name = "randomListBox";
            this.randomListBox.Size = new System.Drawing.Size(261, 404);
            this.randomListBox.TabIndex = 0;
            // 
            // randomLabel
            // 
            this.randomLabel.AutoSize = true;
            this.randomLabel.Location = new System.Drawing.Point(63, 41);
            this.randomLabel.Name = "randomLabel";
            this.randomLabel.Size = new System.Drawing.Size(164, 20);
            this.randomLabel.TabIndex = 1;
            this.randomLabel.Text = "Random.txt Contents:";
            // 
            // reloadButton
            // 
            this.reloadButton.Location = new System.Drawing.Point(67, 488);
            this.reloadButton.Name = "reloadButton";
            this.reloadButton.Size = new System.Drawing.Size(75, 32);
            this.reloadButton.TabIndex = 2;
            this.reloadButton.Text = "Reload";
            this.reloadButton.UseVisualStyleBackColor = true;
            this.reloadButton.Click += new System.EventHandler(this.reloadButton_Click);
            // 
            // inputGroupBox
            // 
            this.inputGroupBox.Controls.Add(this.rangeButton);
            this.inputGroupBox.Controls.Add(this.removeNegativesButton);
            this.inputGroupBox.Controls.Add(this.randomListBox);
            this.inputGroupBox.Controls.Add(this.randomLabel);
            this.inputGroupBox.Controls.Add(this.reloadButton);
            this.inputGroupBox.Location = new System.Drawing.Point(12, 12);
            this.inputGroupBox.Name = "inputGroupBox";
            this.inputGroupBox.Size = new System.Drawing.Size(508, 546);
            this.inputGroupBox.TabIndex = 4;
            this.inputGroupBox.TabStop = false;
            this.inputGroupBox.Text = "Input";
            // 
            // outputGroupBox
            // 
            this.outputGroupBox.Controls.Add(this.resultsLabel);
            this.outputGroupBox.Controls.Add(this.exitButton);
            this.outputGroupBox.Controls.Add(this.outputListBox);
            this.outputGroupBox.Location = new System.Drawing.Point(557, 12);
            this.outputGroupBox.Name = "outputGroupBox";
            this.outputGroupBox.Size = new System.Drawing.Size(308, 546);
            this.outputGroupBox.TabIndex = 5;
            this.outputGroupBox.TabStop = false;
            this.outputGroupBox.Text = "Output";
            // 
            // outputListBox
            // 
            this.outputListBox.FormattingEnabled = true;
            this.outputListBox.ItemHeight = 20;
            this.outputListBox.Location = new System.Drawing.Point(23, 77);
            this.outputListBox.Name = "outputListBox";
            this.outputListBox.Size = new System.Drawing.Size(261, 404);
            this.outputListBox.TabIndex = 5;
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(205, 487);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(79, 32);
            this.exitButton.TabIndex = 6;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // resultsLabel
            // 
            this.resultsLabel.AutoSize = true;
            this.resultsLabel.Location = new System.Drawing.Point(29, 41);
            this.resultsLabel.Name = "resultsLabel";
            this.resultsLabel.Size = new System.Drawing.Size(158, 20);
            this.resultsLabel.TabIndex = 7;
            this.resultsLabel.Text = "Manipulated Results:";
            // 
            // removeNegativesButton
            // 
            this.removeNegativesButton.Location = new System.Drawing.Point(335, 121);
            this.removeNegativesButton.Name = "removeNegativesButton";
            this.removeNegativesButton.Size = new System.Drawing.Size(160, 42);
            this.removeNegativesButton.TabIndex = 3;
            this.removeNegativesButton.Text = "Remove Negatives";
            this.removeNegativesButton.UseVisualStyleBackColor = true;
            this.removeNegativesButton.Click += new System.EventHandler(this.removeNegativesButton_Click);
            // 
            // rangeButton
            // 
            this.rangeButton.Location = new System.Drawing.Point(335, 252);
            this.rangeButton.Name = "rangeButton";
            this.rangeButton.Size = new System.Drawing.Size(160, 42);
            this.rangeButton.TabIndex = 4;
            this.rangeButton.Text = "Only in 1-10 Range";
            this.rangeButton.UseVisualStyleBackColor = true;
            this.rangeButton.Click += new System.EventHandler(this.rangeButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(875, 574);
            this.Controls.Add(this.outputGroupBox);
            this.Controls.Add(this.inputGroupBox);
            this.Name = "Form1";
            this.Text = "List Manipulator";
            this.inputGroupBox.ResumeLayout(false);
            this.inputGroupBox.PerformLayout();
            this.outputGroupBox.ResumeLayout(false);
            this.outputGroupBox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox randomListBox;
        private System.Windows.Forms.Label randomLabel;
        private System.Windows.Forms.Button reloadButton;
        private System.Windows.Forms.GroupBox inputGroupBox;
        private System.Windows.Forms.GroupBox outputGroupBox;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.ListBox outputListBox;
        private System.Windows.Forms.Label resultsLabel;
        private System.Windows.Forms.Button removeNegativesButton;
        private System.Windows.Forms.Button rangeButton;
    }
}


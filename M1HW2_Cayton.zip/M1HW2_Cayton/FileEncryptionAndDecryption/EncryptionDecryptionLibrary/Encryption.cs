﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace EncryptionDecryptionLibrary
{
    public static class Encryption
    {

        public static Dictionary<char, char> codes = new Dictionary<char, char>()
            { {'A','%'}, {'a','9'}, {'B','@'}, {'b','-'},
        {'C','#'}, {'c','&'}, {'D','*'}, {'d','('}, {'E','>'}, {'e','<'},
        {'F','|'}, {'f','y'}, {'G','/'}, {'g','='}, {'H','+'}, {'h','~'},
        {'I','^'}, {'i','$'}, {'J','['}, {'j',']'}, {'K','{'}, {'k','}'},
        {'L','1'}, {'l','8'}, {'M','3'}, {'m','2'}, {'N','7'}, {'n','6'}, 
        {'O','5'}, {'o','4'}, {'P','0'}, {'p','b'}, {'Q','W'}, {'q','x'}, 
        {'R','n'}, {'r','j'}, {'S','e'}, {'s','q'}, {'T','h'}, {'t','u'}, 
        {'U','z'}, {'u','r'}, {'V','c'}, {'v','m'}, {'W','s'}, {'w','l'},
        {'X','G'}, {'x','A'}, {'Y','V'}, {'y','F'}, {'Z','o'}, {'z','p'}
        };
            
        public static void EncryptTextFile(string inputFilePath, string outputFilePath)
        {
            // Encrypts the given text file using the characters as keys and writing the returned values
            StreamReader inputFile = File.OpenText(@inputFilePath);
            StreamWriter outputFile = File.CreateText(@outputFilePath);
            string currentLine;
            
            while (!inputFile.EndOfStream)
            {
                currentLine = inputFile.ReadLine();
                string outputLine = "";

                for (int i = 0; i < currentLine.Length; i++)
                {
                    if (codes.ContainsKey(currentLine[i]))
                    {
                        outputLine += codes[currentLine[i]]; // Encrypt the strings characters
                    }
                    else
                    {
                        outputLine += currentLine[i]; // Add un-encryptable entries normally, such as spaces
                    }
                }

                outputFile.WriteLine(outputLine); // Write Encrypted Text to Output File

            }

            inputFile.Close();
            outputFile.Close();

        }

        public static void DecryptTextFile(string inputFilePath, string outputFilePath)
        {
            // Decrypts the given text file by searching for the matching key to the current character value
            StreamReader inputFile = File.OpenText(@inputFilePath);
            StreamWriter outputFile = File.CreateText(@outputFilePath);
            string currentLine;

            while (!inputFile.EndOfStream)
            {
                currentLine = inputFile.ReadLine();
                string outputLine = "";
                char currentKey;

                for (int i = 0; i < currentLine.Length; i++)
                {
                    if (codes.ContainsValue(currentLine[i]))
                    {
                        // Find key
                        foreach (var keyValuePair in codes)
                        {
                            if (keyValuePair.Value == currentLine[i])
                            {
                                currentKey = keyValuePair.Key;
                                outputLine += currentKey; // Get the key for the current character & add it
                                break; // End the loop upon finding the key
                            }
                        }
                    }
                    else
                    {
                        outputLine += currentLine[i]; // Add un-decryptable entries normally, such as spaces
                    }
                }

                outputFile.WriteLine(outputLine); // Write Decrypted Text to Output File

            }

            inputFile.Close();
            outputFile.Close();

        }

    }
}
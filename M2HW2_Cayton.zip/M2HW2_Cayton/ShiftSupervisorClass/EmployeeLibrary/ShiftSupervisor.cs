﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeLibrary
{
    public class ShiftSupervisor : Employee
    {
        public ShiftSupervisor() // Default Constructor
        {
            // Default Values
            AnualSalary = 0.0m;
            AnualProduction = 0.0m;
        }

        public decimal AnualSalary { get; set; }
        public decimal AnualProduction { get; set; }
    }
}

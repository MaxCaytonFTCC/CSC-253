﻿/**
* 10/23/2023
* CSC 253
* Max Cayton
* This program displays a list of prime numbers that are less than or equal to an input integer.
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PrimeLibrary;

namespace WinUI
{
    public partial class Form1 : Form
    {        
        public Form1()
        {            
            InitializeComponent();
        }

        private void submitButton_Click(object sender, EventArgs e)
        {            
            try
            {                
                int input = int.Parse(integerTextBox.Text);
                if (input > 90000) throw new Exception("Integer Too Large"); // Throw an exception if the number is too big to prevent freezing
                SetListBox(PrimeNumber.GetPrimeNumbers(input));
            }
            catch
            {
                MessageBox.Show("Something went wrong...\nPlease Try Again");
            }
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            integerTextBox.Text = string.Empty;
            primeListBox.Items.Clear();
        }

        private void SetListBox(List<int> ints)
        {
            primeListBox.Items.Clear();
            foreach (int i in ints) primeListBox.Items.Add(i);            
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
﻿namespace WinUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.inputInstructionLabel = new System.Windows.Forms.Label();
            this.outputLabel = new System.Windows.Forms.Label();
            this.courseNumberTextBox = new System.Windows.Forms.TextBox();
            this.roomNumberTextBox = new System.Windows.Forms.TextBox();
            this.instructorTextBox = new System.Windows.Forms.TextBox();
            this.meetingTimeTextBox = new System.Windows.Forms.TextBox();
            this.submitButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.clearButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // inputInstructionLabel
            // 
            this.inputInstructionLabel.AutoSize = true;
            this.inputInstructionLabel.Location = new System.Drawing.Point(37, 62);
            this.inputInstructionLabel.Name = "inputInstructionLabel";
            this.inputInstructionLabel.Size = new System.Drawing.Size(175, 20);
            this.inputInstructionLabel.TabIndex = 0;
            this.inputInstructionLabel.Text = "Enter a course number:";
            // 
            // outputLabel
            // 
            this.outputLabel.AutoSize = true;
            this.outputLabel.Location = new System.Drawing.Point(402, 43);
            this.outputLabel.Name = "outputLabel";
            this.outputLabel.Size = new System.Drawing.Size(116, 100);
            this.outputLabel.TabIndex = 1;
            this.outputLabel.Text = "Room Number:\r\n\r\nInstructor:\r\n\r\nMeeting Time: ";
            // 
            // courseNumberTextBox
            // 
            this.courseNumberTextBox.Location = new System.Drawing.Point(219, 55);
            this.courseNumberTextBox.Name = "courseNumberTextBox";
            this.courseNumberTextBox.Size = new System.Drawing.Size(100, 26);
            this.courseNumberTextBox.TabIndex = 2;
            // 
            // roomNumberTextBox
            // 
            this.roomNumberTextBox.Location = new System.Drawing.Point(524, 40);
            this.roomNumberTextBox.Name = "roomNumberTextBox";
            this.roomNumberTextBox.Size = new System.Drawing.Size(100, 26);
            this.roomNumberTextBox.TabIndex = 3;
            // 
            // instructorTextBox
            // 
            this.instructorTextBox.Location = new System.Drawing.Point(524, 85);
            this.instructorTextBox.Name = "instructorTextBox";
            this.instructorTextBox.Size = new System.Drawing.Size(100, 26);
            this.instructorTextBox.TabIndex = 4;
            // 
            // meetingTimeTextBox
            // 
            this.meetingTimeTextBox.Location = new System.Drawing.Point(524, 129);
            this.meetingTimeTextBox.Name = "meetingTimeTextBox";
            this.meetingTimeTextBox.Size = new System.Drawing.Size(100, 26);
            this.meetingTimeTextBox.TabIndex = 5;
            // 
            // submitButton
            // 
            this.submitButton.Location = new System.Drawing.Point(41, 179);
            this.submitButton.Name = "submitButton";
            this.submitButton.Size = new System.Drawing.Size(80, 40);
            this.submitButton.TabIndex = 6;
            this.submitButton.Text = "Submit";
            this.submitButton.UseVisualStyleBackColor = true;
            this.submitButton.Click += new System.EventHandler(this.submitButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(549, 179);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 38);
            this.exitButton.TabIndex = 7;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(137, 179);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(75, 40);
            this.clearButton.TabIndex = 8;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(653, 248);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.submitButton);
            this.Controls.Add(this.meetingTimeTextBox);
            this.Controls.Add(this.instructorTextBox);
            this.Controls.Add(this.roomNumberTextBox);
            this.Controls.Add(this.courseNumberTextBox);
            this.Controls.Add(this.outputLabel);
            this.Controls.Add(this.inputInstructionLabel);
            this.Name = "Form1";
            this.Text = "Course Information";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label inputInstructionLabel;
        private System.Windows.Forms.Label outputLabel;
        private System.Windows.Forms.TextBox courseNumberTextBox;
        private System.Windows.Forms.TextBox roomNumberTextBox;
        private System.Windows.Forms.TextBox instructorTextBox;
        private System.Windows.Forms.TextBox meetingTimeTextBox;
        private System.Windows.Forms.Button submitButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Button clearButton;
    }
}


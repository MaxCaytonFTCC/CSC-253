﻿/**
* 9/4/2023
* CSC 253
* Max Cayton
* This program can open two specific files and encrypt or decrypt their contents to one another, as well allowing the user to write to any of the files after making changes.
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using EncryptionDecryptionLibrary;

namespace WinUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        #region General Buttons
        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void clearButton_Click(object sender, EventArgs e)
        {
            regularTextRichTextBox.Clear();
            encryptedRichTextBox.Clear();
        }
        #endregion

        #region Open File Buttons
        private void openRegularTextButton_Click(object sender, EventArgs e)
        {
            StreamReader inputFile;

            // Open File
            inputFile = File.OpenText(@"../../../EncryptionDecryptionLibrary/Docs/regular_text.txt");

            // Display File Contents
            regularTextRichTextBox.Clear();
            regularTextRichTextBox.Text = inputFile.ReadToEnd();

            inputFile.Close();
            
        }
        private void encryptedOpenButton_Click(object sender, EventArgs e)
        {

            StreamReader inputFile;

            // Open File
            inputFile = File.OpenText(@"../../../EncryptionDecryptionLibrary/Docs/encrypted_text.txt");

            // Display File Contents
            encryptedRichTextBox.Clear();
            encryptedRichTextBox.Text = inputFile.ReadToEnd();

            inputFile.Close();
        }

        #endregion

        #region Write to File Buttons
        private void writeButton_Click(object sender, EventArgs e)
        {
            StreamWriter outputFile;
            // Open File
            outputFile = File.CreateText(@"../../../EncryptionDecryptionLibrary/Docs/regular_text.txt");

            // Write File Contents            
            outputFile.Write(regularTextRichTextBox.Text);
            outputFile.Close();
        }
        private void encryptedWriteButton_Click(object sender, EventArgs e)
        {
            StreamWriter outputFile;
            // Open File
            outputFile = File.CreateText(@"../../../EncryptionDecryptionLibrary/Docs/encrypted_text.txt");

            // Write File Contents            
            outputFile.Write(encryptedRichTextBox.Text);
            outputFile.Close();
        }
        #endregion

        #region Encryption & Decryption Buttons
        private void encryptButton_Click(object sender, EventArgs e)
        {
            StreamReader inputFile;

            // Encrypt the file
            Encryption.EncryptTextFile("../../../EncryptionDecryptionLibrary/Docs/regular_text.txt", "../../../EncryptionDecryptionLibrary/Docs/encrypted_text.txt");

            // Open File
            inputFile = File.OpenText(@"../../../EncryptionDecryptionLibrary/Docs/encrypted_text.txt");

            // Display Encrypted File Contents
            encryptedRichTextBox.Clear();
            encryptedRichTextBox.Text = inputFile.ReadToEnd();
            regularTextRichTextBox.Clear();

            inputFile.Close();

        }
        private void decryptButton_Click(object sender, EventArgs e)
        {

            StreamReader inputFile;

            // Decrypt the file
            Encryption.DecryptTextFile("../../../EncryptionDecryptionLibrary/Docs/encrypted_text.txt", "../../../EncryptionDecryptionLibrary/Docs/regular_text.txt");

            // Open File
            inputFile = File.OpenText(@"../../../EncryptionDecryptionLibrary/Docs/regular_text.txt");

            // Display Decrypted File Contents
            regularTextRichTextBox.Clear();
            regularTextRichTextBox.Text = inputFile.ReadToEnd();
            encryptedRichTextBox.Clear();

            inputFile.Close();

        }
        #endregion

    }
}

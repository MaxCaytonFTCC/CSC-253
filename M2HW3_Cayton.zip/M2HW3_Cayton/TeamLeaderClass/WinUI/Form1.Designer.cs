﻿namespace WinUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.exitButton = new System.Windows.Forms.Button();
            this.inputGroupBox = new System.Windows.Forms.GroupBox();
            this.trainingHoursTextBox = new System.Windows.Forms.TextBox();
            this.requiredHoursTextBox = new System.Windows.Forms.TextBox();
            this.monthlyBonusTextBox = new System.Windows.Forms.TextBox();
            this.trainingHoursLabel = new System.Windows.Forms.Label();
            this.requiredTrainingHoursLabel = new System.Windows.Forms.Label();
            this.monthlyBonusLabel = new System.Windows.Forms.Label();
            this.shiftRestrictionLabel = new System.Windows.Forms.Label();
            this.submitButton = new System.Windows.Forms.Button();
            this.hourlyPayTextBox = new System.Windows.Forms.TextBox();
            this.shiftNumberTextBox = new System.Windows.Forms.TextBox();
            this.numberTextBox = new System.Windows.Forms.TextBox();
            this.nameTextBox = new System.Windows.Forms.TextBox();
            this.hourlyPayRateLabel = new System.Windows.Forms.Label();
            this.shiftNumberLabel = new System.Windows.Forms.Label();
            this.numberLabel = new System.Windows.Forms.Label();
            this.nameLabel = new System.Windows.Forms.Label();
            this.outputGroupBox = new System.Windows.Forms.GroupBox();
            this.outputTrainingHoursTextBox = new System.Windows.Forms.TextBox();
            this.outputRequiredHoursTextBox = new System.Windows.Forms.TextBox();
            this.outputMonthlyBonusTextBox = new System.Windows.Forms.TextBox();
            this.outputTrainingHoursLabel = new System.Windows.Forms.Label();
            this.outputRequiredTrainingHoursLabel = new System.Windows.Forms.Label();
            this.outputMonthlyBonusLabel = new System.Windows.Forms.Label();
            this.displayButton = new System.Windows.Forms.Button();
            this.clearButton = new System.Windows.Forms.Button();
            this.outputHourlyPayTextBox = new System.Windows.Forms.TextBox();
            this.outputShiftNumberTextBox = new System.Windows.Forms.TextBox();
            this.outputNumberTextBox = new System.Windows.Forms.TextBox();
            this.outputNameTextBox = new System.Windows.Forms.TextBox();
            this.outputHourlyPayRateLabel = new System.Windows.Forms.Label();
            this.outputNumberLabel = new System.Windows.Forms.Label();
            this.outputShiftNumberLabel = new System.Windows.Forms.Label();
            this.outputNameLabel = new System.Windows.Forms.Label();
            this.inputGroupBox.SuspendLayout();
            this.outputGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(676, 420);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(83, 32);
            this.exitButton.TabIndex = 0;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // inputGroupBox
            // 
            this.inputGroupBox.Controls.Add(this.trainingHoursTextBox);
            this.inputGroupBox.Controls.Add(this.requiredHoursTextBox);
            this.inputGroupBox.Controls.Add(this.monthlyBonusTextBox);
            this.inputGroupBox.Controls.Add(this.trainingHoursLabel);
            this.inputGroupBox.Controls.Add(this.requiredTrainingHoursLabel);
            this.inputGroupBox.Controls.Add(this.monthlyBonusLabel);
            this.inputGroupBox.Controls.Add(this.shiftRestrictionLabel);
            this.inputGroupBox.Controls.Add(this.submitButton);
            this.inputGroupBox.Controls.Add(this.hourlyPayTextBox);
            this.inputGroupBox.Controls.Add(this.shiftNumberTextBox);
            this.inputGroupBox.Controls.Add(this.numberTextBox);
            this.inputGroupBox.Controls.Add(this.nameTextBox);
            this.inputGroupBox.Controls.Add(this.hourlyPayRateLabel);
            this.inputGroupBox.Controls.Add(this.shiftNumberLabel);
            this.inputGroupBox.Controls.Add(this.numberLabel);
            this.inputGroupBox.Controls.Add(this.nameLabel);
            this.inputGroupBox.Location = new System.Drawing.Point(12, 12);
            this.inputGroupBox.Name = "inputGroupBox";
            this.inputGroupBox.Size = new System.Drawing.Size(381, 402);
            this.inputGroupBox.TabIndex = 1;
            this.inputGroupBox.TabStop = false;
            this.inputGroupBox.Text = "Input";
            // 
            // trainingHoursTextBox
            // 
            this.trainingHoursTextBox.Location = new System.Drawing.Point(149, 310);
            this.trainingHoursTextBox.Name = "trainingHoursTextBox";
            this.trainingHoursTextBox.Size = new System.Drawing.Size(100, 26);
            this.trainingHoursTextBox.TabIndex = 15;
            // 
            // requiredHoursTextBox
            // 
            this.requiredHoursTextBox.Location = new System.Drawing.Point(213, 266);
            this.requiredHoursTextBox.Name = "requiredHoursTextBox";
            this.requiredHoursTextBox.Size = new System.Drawing.Size(100, 26);
            this.requiredHoursTextBox.TabIndex = 14;
            // 
            // monthlyBonusTextBox
            // 
            this.monthlyBonusTextBox.Location = new System.Drawing.Point(155, 230);
            this.monthlyBonusTextBox.Name = "monthlyBonusTextBox";
            this.monthlyBonusTextBox.Size = new System.Drawing.Size(100, 26);
            this.monthlyBonusTextBox.TabIndex = 13;
            // 
            // trainingHoursLabel
            // 
            this.trainingHoursLabel.AutoSize = true;
            this.trainingHoursLabel.Location = new System.Drawing.Point(26, 310);
            this.trainingHoursLabel.Name = "trainingHoursLabel";
            this.trainingHoursLabel.Size = new System.Drawing.Size(116, 20);
            this.trainingHoursLabel.TabIndex = 12;
            this.trainingHoursLabel.Text = "Training Hours:";
            // 
            // requiredTrainingHoursLabel
            // 
            this.requiredTrainingHoursLabel.AutoSize = true;
            this.requiredTrainingHoursLabel.Location = new System.Drawing.Point(22, 269);
            this.requiredTrainingHoursLabel.Name = "requiredTrainingHoursLabel";
            this.requiredTrainingHoursLabel.Size = new System.Drawing.Size(185, 20);
            this.requiredTrainingHoursLabel.TabIndex = 11;
            this.requiredTrainingHoursLabel.Text = "Required Training Hours:";
            // 
            // monthlyBonusLabel
            // 
            this.monthlyBonusLabel.AutoSize = true;
            this.monthlyBonusLabel.Location = new System.Drawing.Point(22, 230);
            this.monthlyBonusLabel.Name = "monthlyBonusLabel";
            this.monthlyBonusLabel.Size = new System.Drawing.Size(118, 20);
            this.monthlyBonusLabel.TabIndex = 10;
            this.monthlyBonusLabel.Text = "Monthly Bonus:";
            // 
            // shiftRestrictionLabel
            // 
            this.shiftRestrictionLabel.AutoSize = true;
            this.shiftRestrictionLabel.Location = new System.Drawing.Point(241, 150);
            this.shiftRestrictionLabel.Name = "shiftRestrictionLabel";
            this.shiftRestrictionLabel.Size = new System.Drawing.Size(120, 20);
            this.shiftRestrictionLabel.TabIndex = 9;
            this.shiftRestrictionLabel.Text = "(Must be 1 or 2)";
            // 
            // submitButton
            // 
            this.submitButton.Location = new System.Drawing.Point(278, 359);
            this.submitButton.Name = "submitButton";
            this.submitButton.Size = new System.Drawing.Size(97, 37);
            this.submitButton.TabIndex = 8;
            this.submitButton.Text = "Submit";
            this.submitButton.UseVisualStyleBackColor = true;
            this.submitButton.Click += new System.EventHandler(this.submitButton_Click);
            // 
            // hourlyPayTextBox
            // 
            this.hourlyPayTextBox.Location = new System.Drawing.Point(155, 185);
            this.hourlyPayTextBox.Name = "hourlyPayTextBox";
            this.hourlyPayTextBox.Size = new System.Drawing.Size(100, 26);
            this.hourlyPayTextBox.TabIndex = 7;
            // 
            // shiftNumberTextBox
            // 
            this.shiftNumberTextBox.Location = new System.Drawing.Point(135, 147);
            this.shiftNumberTextBox.Name = "shiftNumberTextBox";
            this.shiftNumberTextBox.Size = new System.Drawing.Size(100, 26);
            this.shiftNumberTextBox.TabIndex = 6;
            // 
            // numberTextBox
            // 
            this.numberTextBox.Location = new System.Drawing.Point(98, 109);
            this.numberTextBox.Name = "numberTextBox";
            this.numberTextBox.Size = new System.Drawing.Size(100, 26);
            this.numberTextBox.TabIndex = 5;
            // 
            // nameTextBox
            // 
            this.nameTextBox.Location = new System.Drawing.Point(83, 73);
            this.nameTextBox.Name = "nameTextBox";
            this.nameTextBox.Size = new System.Drawing.Size(100, 26);
            this.nameTextBox.TabIndex = 4;
            // 
            // hourlyPayRateLabel
            // 
            this.hourlyPayRateLabel.AutoSize = true;
            this.hourlyPayRateLabel.Location = new System.Drawing.Point(22, 185);
            this.hourlyPayRateLabel.Name = "hourlyPayRateLabel";
            this.hourlyPayRateLabel.Size = new System.Drawing.Size(127, 20);
            this.hourlyPayRateLabel.TabIndex = 3;
            this.hourlyPayRateLabel.Text = "Hourly Pay Rate:";
            // 
            // shiftNumberLabel
            // 
            this.shiftNumberLabel.AutoSize = true;
            this.shiftNumberLabel.Location = new System.Drawing.Point(22, 147);
            this.shiftNumberLabel.Name = "shiftNumberLabel";
            this.shiftNumberLabel.Size = new System.Drawing.Size(106, 20);
            this.shiftNumberLabel.TabIndex = 2;
            this.shiftNumberLabel.Text = "Shift Number:";
            // 
            // numberLabel
            // 
            this.numberLabel.AutoSize = true;
            this.numberLabel.Location = new System.Drawing.Point(22, 109);
            this.numberLabel.Name = "numberLabel";
            this.numberLabel.Size = new System.Drawing.Size(69, 20);
            this.numberLabel.TabIndex = 1;
            this.numberLabel.Text = "Number:";
            // 
            // nameLabel
            // 
            this.nameLabel.AutoSize = true;
            this.nameLabel.Location = new System.Drawing.Point(22, 73);
            this.nameLabel.Name = "nameLabel";
            this.nameLabel.Size = new System.Drawing.Size(55, 20);
            this.nameLabel.TabIndex = 0;
            this.nameLabel.Text = "Name:";
            // 
            // outputGroupBox
            // 
            this.outputGroupBox.Controls.Add(this.outputTrainingHoursTextBox);
            this.outputGroupBox.Controls.Add(this.outputRequiredHoursTextBox);
            this.outputGroupBox.Controls.Add(this.outputMonthlyBonusTextBox);
            this.outputGroupBox.Controls.Add(this.outputTrainingHoursLabel);
            this.outputGroupBox.Controls.Add(this.outputRequiredTrainingHoursLabel);
            this.outputGroupBox.Controls.Add(this.outputMonthlyBonusLabel);
            this.outputGroupBox.Controls.Add(this.displayButton);
            this.outputGroupBox.Controls.Add(this.clearButton);
            this.outputGroupBox.Controls.Add(this.outputHourlyPayTextBox);
            this.outputGroupBox.Controls.Add(this.outputShiftNumberTextBox);
            this.outputGroupBox.Controls.Add(this.outputNumberTextBox);
            this.outputGroupBox.Controls.Add(this.outputNameTextBox);
            this.outputGroupBox.Controls.Add(this.outputHourlyPayRateLabel);
            this.outputGroupBox.Controls.Add(this.outputNumberLabel);
            this.outputGroupBox.Controls.Add(this.outputShiftNumberLabel);
            this.outputGroupBox.Controls.Add(this.outputNameLabel);
            this.outputGroupBox.Location = new System.Drawing.Point(409, 12);
            this.outputGroupBox.Name = "outputGroupBox";
            this.outputGroupBox.Size = new System.Drawing.Size(348, 402);
            this.outputGroupBox.TabIndex = 2;
            this.outputGroupBox.TabStop = false;
            this.outputGroupBox.Text = "Object Properties";
            // 
            // outputTrainingHoursTextBox
            // 
            this.outputTrainingHoursTextBox.Location = new System.Drawing.Point(152, 307);
            this.outputTrainingHoursTextBox.Name = "outputTrainingHoursTextBox";
            this.outputTrainingHoursTextBox.Size = new System.Drawing.Size(100, 26);
            this.outputTrainingHoursTextBox.TabIndex = 16;
            // 
            // outputRequiredHoursTextBox
            // 
            this.outputRequiredHoursTextBox.Location = new System.Drawing.Point(219, 269);
            this.outputRequiredHoursTextBox.Name = "outputRequiredHoursTextBox";
            this.outputRequiredHoursTextBox.Size = new System.Drawing.Size(100, 26);
            this.outputRequiredHoursTextBox.TabIndex = 15;
            // 
            // outputMonthlyBonusTextBox
            // 
            this.outputMonthlyBonusTextBox.Location = new System.Drawing.Point(162, 230);
            this.outputMonthlyBonusTextBox.Name = "outputMonthlyBonusTextBox";
            this.outputMonthlyBonusTextBox.Size = new System.Drawing.Size(100, 26);
            this.outputMonthlyBonusTextBox.TabIndex = 14;
            // 
            // outputTrainingHoursLabel
            // 
            this.outputTrainingHoursLabel.AutoSize = true;
            this.outputTrainingHoursLabel.Location = new System.Drawing.Point(30, 310);
            this.outputTrainingHoursLabel.Name = "outputTrainingHoursLabel";
            this.outputTrainingHoursLabel.Size = new System.Drawing.Size(116, 20);
            this.outputTrainingHoursLabel.TabIndex = 13;
            this.outputTrainingHoursLabel.Text = "Training Hours:";
            // 
            // outputRequiredTrainingHoursLabel
            // 
            this.outputRequiredTrainingHoursLabel.AutoSize = true;
            this.outputRequiredTrainingHoursLabel.Location = new System.Drawing.Point(28, 269);
            this.outputRequiredTrainingHoursLabel.Name = "outputRequiredTrainingHoursLabel";
            this.outputRequiredTrainingHoursLabel.Size = new System.Drawing.Size(185, 20);
            this.outputRequiredTrainingHoursLabel.TabIndex = 12;
            this.outputRequiredTrainingHoursLabel.Text = "Required Training Hours:";
            // 
            // outputMonthlyBonusLabel
            // 
            this.outputMonthlyBonusLabel.AutoSize = true;
            this.outputMonthlyBonusLabel.Location = new System.Drawing.Point(28, 230);
            this.outputMonthlyBonusLabel.Name = "outputMonthlyBonusLabel";
            this.outputMonthlyBonusLabel.Size = new System.Drawing.Size(118, 20);
            this.outputMonthlyBonusLabel.TabIndex = 11;
            this.outputMonthlyBonusLabel.Text = "Monthly Bonus:";
            // 
            // displayButton
            // 
            this.displayButton.Location = new System.Drawing.Point(7, 359);
            this.displayButton.Name = "displayButton";
            this.displayButton.Size = new System.Drawing.Size(90, 37);
            this.displayButton.TabIndex = 10;
            this.displayButton.Text = "Display";
            this.displayButton.UseVisualStyleBackColor = true;
            this.displayButton.Click += new System.EventHandler(this.displayButton_Click);
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(255, 360);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(87, 34);
            this.clearButton.TabIndex = 9;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // outputHourlyPayTextBox
            // 
            this.outputHourlyPayTextBox.Location = new System.Drawing.Point(162, 184);
            this.outputHourlyPayTextBox.Name = "outputHourlyPayTextBox";
            this.outputHourlyPayTextBox.Size = new System.Drawing.Size(100, 26);
            this.outputHourlyPayTextBox.TabIndex = 8;
            // 
            // outputShiftNumberTextBox
            // 
            this.outputShiftNumberTextBox.Location = new System.Drawing.Point(140, 144);
            this.outputShiftNumberTextBox.Name = "outputShiftNumberTextBox";
            this.outputShiftNumberTextBox.Size = new System.Drawing.Size(100, 26);
            this.outputShiftNumberTextBox.TabIndex = 7;
            // 
            // outputNumberTextBox
            // 
            this.outputNumberTextBox.Location = new System.Drawing.Point(103, 106);
            this.outputNumberTextBox.Name = "outputNumberTextBox";
            this.outputNumberTextBox.Size = new System.Drawing.Size(100, 26);
            this.outputNumberTextBox.TabIndex = 6;
            // 
            // outputNameTextBox
            // 
            this.outputNameTextBox.Location = new System.Drawing.Point(89, 73);
            this.outputNameTextBox.Name = "outputNameTextBox";
            this.outputNameTextBox.Size = new System.Drawing.Size(100, 26);
            this.outputNameTextBox.TabIndex = 5;
            // 
            // outputHourlyPayRateLabel
            // 
            this.outputHourlyPayRateLabel.AutoSize = true;
            this.outputHourlyPayRateLabel.Location = new System.Drawing.Point(28, 185);
            this.outputHourlyPayRateLabel.Name = "outputHourlyPayRateLabel";
            this.outputHourlyPayRateLabel.Size = new System.Drawing.Size(127, 20);
            this.outputHourlyPayRateLabel.TabIndex = 7;
            this.outputHourlyPayRateLabel.Text = "Hourly Pay Rate:";
            // 
            // outputNumberLabel
            // 
            this.outputNumberLabel.AutoSize = true;
            this.outputNumberLabel.Location = new System.Drawing.Point(28, 109);
            this.outputNumberLabel.Name = "outputNumberLabel";
            this.outputNumberLabel.Size = new System.Drawing.Size(69, 20);
            this.outputNumberLabel.TabIndex = 5;
            this.outputNumberLabel.Text = "Number:";
            // 
            // outputShiftNumberLabel
            // 
            this.outputShiftNumberLabel.AutoSize = true;
            this.outputShiftNumberLabel.Location = new System.Drawing.Point(28, 147);
            this.outputShiftNumberLabel.Name = "outputShiftNumberLabel";
            this.outputShiftNumberLabel.Size = new System.Drawing.Size(106, 20);
            this.outputShiftNumberLabel.TabIndex = 6;
            this.outputShiftNumberLabel.Text = "Shift Number:";
            // 
            // outputNameLabel
            // 
            this.outputNameLabel.AutoSize = true;
            this.outputNameLabel.Location = new System.Drawing.Point(28, 73);
            this.outputNameLabel.Name = "outputNameLabel";
            this.outputNameLabel.Size = new System.Drawing.Size(55, 20);
            this.outputNameLabel.TabIndex = 4;
            this.outputNameLabel.Text = "Name:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(771, 464);
            this.Controls.Add(this.outputGroupBox);
            this.Controls.Add(this.inputGroupBox);
            this.Controls.Add(this.exitButton);
            this.Name = "Form1";
            this.Text = "TeamLeader Class";
            this.inputGroupBox.ResumeLayout(false);
            this.inputGroupBox.PerformLayout();
            this.outputGroupBox.ResumeLayout(false);
            this.outputGroupBox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.GroupBox inputGroupBox;
        private System.Windows.Forms.Label shiftNumberLabel;
        private System.Windows.Forms.Label numberLabel;
        private System.Windows.Forms.Label nameLabel;
        private System.Windows.Forms.GroupBox outputGroupBox;
        private System.Windows.Forms.Label hourlyPayRateLabel;
        private System.Windows.Forms.Label outputHourlyPayRateLabel;
        private System.Windows.Forms.Label outputNumberLabel;
        private System.Windows.Forms.Label outputShiftNumberLabel;
        private System.Windows.Forms.Label outputNameLabel;
        private System.Windows.Forms.TextBox shiftNumberTextBox;
        private System.Windows.Forms.TextBox numberTextBox;
        private System.Windows.Forms.TextBox nameTextBox;
        private System.Windows.Forms.TextBox outputHourlyPayTextBox;
        private System.Windows.Forms.TextBox outputShiftNumberTextBox;
        private System.Windows.Forms.TextBox outputNumberTextBox;
        private System.Windows.Forms.TextBox outputNameTextBox;
        private System.Windows.Forms.Button submitButton;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Button displayButton;
        private System.Windows.Forms.Label shiftRestrictionLabel;
        private System.Windows.Forms.Label requiredTrainingHoursLabel;
        private System.Windows.Forms.Label monthlyBonusLabel;
        private System.Windows.Forms.TextBox hourlyPayTextBox;
        private System.Windows.Forms.Label outputRequiredTrainingHoursLabel;
        private System.Windows.Forms.Label outputMonthlyBonusLabel;
        private System.Windows.Forms.TextBox trainingHoursTextBox;
        private System.Windows.Forms.TextBox requiredHoursTextBox;
        private System.Windows.Forms.TextBox monthlyBonusTextBox;
        private System.Windows.Forms.Label trainingHoursLabel;
        private System.Windows.Forms.TextBox outputTrainingHoursTextBox;
        private System.Windows.Forms.TextBox outputRequiredHoursTextBox;
        private System.Windows.Forms.TextBox outputMonthlyBonusTextBox;
        private System.Windows.Forms.Label outputTrainingHoursLabel;
    }
}


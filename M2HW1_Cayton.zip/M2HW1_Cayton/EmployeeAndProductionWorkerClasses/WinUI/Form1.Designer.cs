﻿namespace WinUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.exitButton = new System.Windows.Forms.Button();
            this.inputGroupBox = new System.Windows.Forms.GroupBox();
            this.outputGroupBox = new System.Windows.Forms.GroupBox();
            this.nameLabel = new System.Windows.Forms.Label();
            this.numberLabel = new System.Windows.Forms.Label();
            this.shiftNumberLabel = new System.Windows.Forms.Label();
            this.hourlyPayRateLabel = new System.Windows.Forms.Label();
            this.outputHourlyPayRateLabel = new System.Windows.Forms.Label();
            this.outputShiftNumberLabel = new System.Windows.Forms.Label();
            this.outputNumberLabel = new System.Windows.Forms.Label();
            this.outputNameLabel = new System.Windows.Forms.Label();
            this.nameTextBox = new System.Windows.Forms.TextBox();
            this.outputNameTextBox = new System.Windows.Forms.TextBox();
            this.numberTextBox = new System.Windows.Forms.TextBox();
            this.outputNumberTextBox = new System.Windows.Forms.TextBox();
            this.shiftNumberTextBox = new System.Windows.Forms.TextBox();
            this.outputShiftNumberTextBox = new System.Windows.Forms.TextBox();
            this.hourlyPayTextBox = new System.Windows.Forms.TextBox();
            this.outputHourlyPayTextBox = new System.Windows.Forms.TextBox();
            this.submitButton = new System.Windows.Forms.Button();
            this.clearButton = new System.Windows.Forms.Button();
            this.displayButton = new System.Windows.Forms.Button();
            this.shiftRestrictionLabel = new System.Windows.Forms.Label();
            this.inputGroupBox.SuspendLayout();
            this.outputGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(674, 296);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(83, 32);
            this.exitButton.TabIndex = 0;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // inputGroupBox
            // 
            this.inputGroupBox.Controls.Add(this.shiftRestrictionLabel);
            this.inputGroupBox.Controls.Add(this.submitButton);
            this.inputGroupBox.Controls.Add(this.hourlyPayTextBox);
            this.inputGroupBox.Controls.Add(this.shiftNumberTextBox);
            this.inputGroupBox.Controls.Add(this.numberTextBox);
            this.inputGroupBox.Controls.Add(this.nameTextBox);
            this.inputGroupBox.Controls.Add(this.hourlyPayRateLabel);
            this.inputGroupBox.Controls.Add(this.shiftNumberLabel);
            this.inputGroupBox.Controls.Add(this.numberLabel);
            this.inputGroupBox.Controls.Add(this.nameLabel);
            this.inputGroupBox.Location = new System.Drawing.Point(12, 12);
            this.inputGroupBox.Name = "inputGroupBox";
            this.inputGroupBox.Size = new System.Drawing.Size(381, 278);
            this.inputGroupBox.TabIndex = 1;
            this.inputGroupBox.TabStop = false;
            this.inputGroupBox.Text = "Input";
            // 
            // outputGroupBox
            // 
            this.outputGroupBox.Controls.Add(this.displayButton);
            this.outputGroupBox.Controls.Add(this.clearButton);
            this.outputGroupBox.Controls.Add(this.outputHourlyPayTextBox);
            this.outputGroupBox.Controls.Add(this.outputShiftNumberTextBox);
            this.outputGroupBox.Controls.Add(this.outputNumberTextBox);
            this.outputGroupBox.Controls.Add(this.outputNameTextBox);
            this.outputGroupBox.Controls.Add(this.outputHourlyPayRateLabel);
            this.outputGroupBox.Controls.Add(this.outputNumberLabel);
            this.outputGroupBox.Controls.Add(this.outputShiftNumberLabel);
            this.outputGroupBox.Controls.Add(this.outputNameLabel);
            this.outputGroupBox.Location = new System.Drawing.Point(409, 12);
            this.outputGroupBox.Name = "outputGroupBox";
            this.outputGroupBox.Size = new System.Drawing.Size(348, 278);
            this.outputGroupBox.TabIndex = 2;
            this.outputGroupBox.TabStop = false;
            this.outputGroupBox.Text = "Object Properties";
            // 
            // nameLabel
            // 
            this.nameLabel.AutoSize = true;
            this.nameLabel.Location = new System.Drawing.Point(22, 73);
            this.nameLabel.Name = "nameLabel";
            this.nameLabel.Size = new System.Drawing.Size(55, 20);
            this.nameLabel.TabIndex = 0;
            this.nameLabel.Text = "Name:";
            // 
            // numberLabel
            // 
            this.numberLabel.AutoSize = true;
            this.numberLabel.Location = new System.Drawing.Point(22, 109);
            this.numberLabel.Name = "numberLabel";
            this.numberLabel.Size = new System.Drawing.Size(69, 20);
            this.numberLabel.TabIndex = 1;
            this.numberLabel.Text = "Number:";
            // 
            // shiftNumberLabel
            // 
            this.shiftNumberLabel.AutoSize = true;
            this.shiftNumberLabel.Location = new System.Drawing.Point(22, 147);
            this.shiftNumberLabel.Name = "shiftNumberLabel";
            this.shiftNumberLabel.Size = new System.Drawing.Size(106, 20);
            this.shiftNumberLabel.TabIndex = 2;
            this.shiftNumberLabel.Text = "Shift Number:";
            // 
            // hourlyPayRateLabel
            // 
            this.hourlyPayRateLabel.AutoSize = true;
            this.hourlyPayRateLabel.Location = new System.Drawing.Point(22, 185);
            this.hourlyPayRateLabel.Name = "hourlyPayRateLabel";
            this.hourlyPayRateLabel.Size = new System.Drawing.Size(127, 20);
            this.hourlyPayRateLabel.TabIndex = 3;
            this.hourlyPayRateLabel.Text = "Hourly Pay Rate:";
            // 
            // outputHourlyPayRateLabel
            // 
            this.outputHourlyPayRateLabel.AutoSize = true;
            this.outputHourlyPayRateLabel.Location = new System.Drawing.Point(28, 185);
            this.outputHourlyPayRateLabel.Name = "outputHourlyPayRateLabel";
            this.outputHourlyPayRateLabel.Size = new System.Drawing.Size(127, 20);
            this.outputHourlyPayRateLabel.TabIndex = 7;
            this.outputHourlyPayRateLabel.Text = "Hourly Pay Rate:";
            // 
            // outputShiftNumberLabel
            // 
            this.outputShiftNumberLabel.AutoSize = true;
            this.outputShiftNumberLabel.Location = new System.Drawing.Point(28, 147);
            this.outputShiftNumberLabel.Name = "outputShiftNumberLabel";
            this.outputShiftNumberLabel.Size = new System.Drawing.Size(106, 20);
            this.outputShiftNumberLabel.TabIndex = 6;
            this.outputShiftNumberLabel.Text = "Shift Number:";
            // 
            // outputNumberLabel
            // 
            this.outputNumberLabel.AutoSize = true;
            this.outputNumberLabel.Location = new System.Drawing.Point(28, 109);
            this.outputNumberLabel.Name = "outputNumberLabel";
            this.outputNumberLabel.Size = new System.Drawing.Size(69, 20);
            this.outputNumberLabel.TabIndex = 5;
            this.outputNumberLabel.Text = "Number:";
            // 
            // outputNameLabel
            // 
            this.outputNameLabel.AutoSize = true;
            this.outputNameLabel.Location = new System.Drawing.Point(28, 73);
            this.outputNameLabel.Name = "outputNameLabel";
            this.outputNameLabel.Size = new System.Drawing.Size(55, 20);
            this.outputNameLabel.TabIndex = 4;
            this.outputNameLabel.Text = "Name:";
            // 
            // nameTextBox
            // 
            this.nameTextBox.Location = new System.Drawing.Point(83, 73);
            this.nameTextBox.Name = "nameTextBox";
            this.nameTextBox.Size = new System.Drawing.Size(100, 26);
            this.nameTextBox.TabIndex = 4;
            // 
            // outputNameTextBox
            // 
            this.outputNameTextBox.Location = new System.Drawing.Point(89, 73);
            this.outputNameTextBox.Name = "outputNameTextBox";
            this.outputNameTextBox.Size = new System.Drawing.Size(100, 26);
            this.outputNameTextBox.TabIndex = 5;
            // 
            // numberTextBox
            // 
            this.numberTextBox.Location = new System.Drawing.Point(98, 109);
            this.numberTextBox.Name = "numberTextBox";
            this.numberTextBox.Size = new System.Drawing.Size(100, 26);
            this.numberTextBox.TabIndex = 5;
            // 
            // outputNumberTextBox
            // 
            this.outputNumberTextBox.Location = new System.Drawing.Point(103, 106);
            this.outputNumberTextBox.Name = "outputNumberTextBox";
            this.outputNumberTextBox.Size = new System.Drawing.Size(100, 26);
            this.outputNumberTextBox.TabIndex = 6;
            // 
            // shiftNumberTextBox
            // 
            this.shiftNumberTextBox.Location = new System.Drawing.Point(135, 147);
            this.shiftNumberTextBox.Name = "shiftNumberTextBox";
            this.shiftNumberTextBox.Size = new System.Drawing.Size(100, 26);
            this.shiftNumberTextBox.TabIndex = 6;
            // 
            // outputShiftNumberTextBox
            // 
            this.outputShiftNumberTextBox.Location = new System.Drawing.Point(140, 144);
            this.outputShiftNumberTextBox.Name = "outputShiftNumberTextBox";
            this.outputShiftNumberTextBox.Size = new System.Drawing.Size(100, 26);
            this.outputShiftNumberTextBox.TabIndex = 7;
            // 
            // hourlyPayTextBox
            // 
            this.hourlyPayTextBox.Location = new System.Drawing.Point(156, 185);
            this.hourlyPayTextBox.Name = "hourlyPayTextBox";
            this.hourlyPayTextBox.Size = new System.Drawing.Size(100, 26);
            this.hourlyPayTextBox.TabIndex = 7;
            // 
            // outputHourlyPayTextBox
            // 
            this.outputHourlyPayTextBox.Location = new System.Drawing.Point(162, 184);
            this.outputHourlyPayTextBox.Name = "outputHourlyPayTextBox";
            this.outputHourlyPayTextBox.Size = new System.Drawing.Size(100, 26);
            this.outputHourlyPayTextBox.TabIndex = 8;
            // 
            // submitButton
            // 
            this.submitButton.Location = new System.Drawing.Point(278, 235);
            this.submitButton.Name = "submitButton";
            this.submitButton.Size = new System.Drawing.Size(97, 37);
            this.submitButton.TabIndex = 8;
            this.submitButton.Text = "Submit";
            this.submitButton.UseVisualStyleBackColor = true;
            this.submitButton.Click += new System.EventHandler(this.submitButton_Click);
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(255, 236);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(87, 34);
            this.clearButton.TabIndex = 9;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // displayButton
            // 
            this.displayButton.Location = new System.Drawing.Point(7, 235);
            this.displayButton.Name = "displayButton";
            this.displayButton.Size = new System.Drawing.Size(90, 37);
            this.displayButton.TabIndex = 10;
            this.displayButton.Text = "Display";
            this.displayButton.UseVisualStyleBackColor = true;
            this.displayButton.Click += new System.EventHandler(this.displayButton_Click);
            // 
            // shiftRestrictionLabel
            // 
            this.shiftRestrictionLabel.AutoSize = true;
            this.shiftRestrictionLabel.Location = new System.Drawing.Point(241, 150);
            this.shiftRestrictionLabel.Name = "shiftRestrictionLabel";
            this.shiftRestrictionLabel.Size = new System.Drawing.Size(120, 20);
            this.shiftRestrictionLabel.TabIndex = 9;
            this.shiftRestrictionLabel.Text = "(Must be 1 or 2)";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(771, 345);
            this.Controls.Add(this.outputGroupBox);
            this.Controls.Add(this.inputGroupBox);
            this.Controls.Add(this.exitButton);
            this.Name = "Form1";
            this.Text = "Employee & Production Worker Classes";
            this.inputGroupBox.ResumeLayout(false);
            this.inputGroupBox.PerformLayout();
            this.outputGroupBox.ResumeLayout(false);
            this.outputGroupBox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.GroupBox inputGroupBox;
        private System.Windows.Forms.Label shiftNumberLabel;
        private System.Windows.Forms.Label numberLabel;
        private System.Windows.Forms.Label nameLabel;
        private System.Windows.Forms.GroupBox outputGroupBox;
        private System.Windows.Forms.Label hourlyPayRateLabel;
        private System.Windows.Forms.Label outputHourlyPayRateLabel;
        private System.Windows.Forms.Label outputNumberLabel;
        private System.Windows.Forms.Label outputShiftNumberLabel;
        private System.Windows.Forms.Label outputNameLabel;
        private System.Windows.Forms.TextBox hourlyPayTextBox;
        private System.Windows.Forms.TextBox shiftNumberTextBox;
        private System.Windows.Forms.TextBox numberTextBox;
        private System.Windows.Forms.TextBox nameTextBox;
        private System.Windows.Forms.TextBox outputHourlyPayTextBox;
        private System.Windows.Forms.TextBox outputShiftNumberTextBox;
        private System.Windows.Forms.TextBox outputNumberTextBox;
        private System.Windows.Forms.TextBox outputNameTextBox;
        private System.Windows.Forms.Button submitButton;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Button displayButton;
        private System.Windows.Forms.Label shiftRestrictionLabel;
    }
}


﻿/**
* 9/18/2023
* CSC 253
* Max Cayton
* This program creates a Shift Supervisor object off of the derived class ShiftSupervisor that inherits from Employee
* and allows the user to display and edit the properties
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using EmployeeLibrary;

namespace WinUI
{
    public partial class Form1 : Form
    {
        ShiftSupervisor supervisor = new ShiftSupervisor();
        public Form1()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void DisplayProperties()
        {          
            outputNameTextBox.Text = supervisor.Name;
            outputNumberTextBox.Text = supervisor.Number.ToString();
            outputAnualSalaryTextBox.Text = supervisor.AnualSalary.ToString("c");
            outputAnualProductionTextBox.Text = supervisor.AnualProduction.ToString("c");            
        }

        private void displayButton_Click(object sender, EventArgs e)
        {
            DisplayProperties();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Display Default Properties
            DisplayProperties();
        }

        private void submitButton_Click(object sender, EventArgs e)
        {
            try
            {
                supervisor.Name = inputNameTextBox.Text;
                supervisor.Number = int.Parse(inputNumberTextBox.Text);
                supervisor.AnualSalary = decimal.Parse(inputAnualSalaryTextBox.Text);
                supervisor.AnualProduction = decimal.Parse(inputAnualProductionTextBox.Text);
                DisplayProperties();
            }            
            catch
            {
                MessageBox.Show("Invalid Input. Please Try Again");
            }
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            inputNameTextBox.Clear();
            inputNumberTextBox.Clear();
            inputAnualSalaryTextBox.Clear();
            inputAnualProductionTextBox.Clear();
            outputNameTextBox.Clear();
            outputNumberTextBox.Clear();
            outputAnualSalaryTextBox.Clear();
            outputAnualProductionTextBox.Clear();
        }
    }
}
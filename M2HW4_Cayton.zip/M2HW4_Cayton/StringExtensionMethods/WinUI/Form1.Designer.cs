﻿namespace WinUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.exitButton = new System.Windows.Forms.Button();
            this.strToCharArrayGroupBox = new System.Windows.Forms.GroupBox();
            this.stringToCharArrayRichTextBox = new System.Windows.Forms.RichTextBox();
            this.strToCharArrayButton = new System.Windows.Forms.Button();
            this.strCharInstructionLabel = new System.Windows.Forms.Label();
            this.dateToStringArrayTextBox = new System.Windows.Forms.GroupBox();
            this.dateToStringArrayButton = new System.Windows.Forms.Button();
            this.dateToArrayInstructionLabel = new System.Windows.Forms.Label();
            this.formatPhoneNumberGroupBox = new System.Windows.Forms.GroupBox();
            this.phoneNumberFormatButton = new System.Windows.Forms.Button();
            this.phoneNumberFormatInstructionLabel = new System.Windows.Forms.Label();
            this.reverseStringGroupBox = new System.Windows.Forms.GroupBox();
            this.reverseStringButton = new System.Windows.Forms.Button();
            this.reverseInstructionLabel = new System.Windows.Forms.Label();
            this.wordCountGroupBox = new System.Windows.Forms.GroupBox();
            this.wordCountButton = new System.Windows.Forms.Button();
            this.wordCountInstructionLabel = new System.Windows.Forms.Label();
            this.dateFormatRichTextBox = new System.Windows.Forms.RichTextBox();
            this.phoneNumberFormatRichTextBox = new System.Windows.Forms.RichTextBox();
            this.reverseStringRichTextBox = new System.Windows.Forms.RichTextBox();
            this.stringWordCountRichTextBox = new System.Windows.Forms.RichTextBox();
            this.stringToCharArrayOutputTextBox = new System.Windows.Forms.TextBox();
            this.formatDateOutputTextBox = new System.Windows.Forms.TextBox();
            this.phoneNumberOutputTextBox = new System.Windows.Forms.TextBox();
            this.reverseStringOutputTextBox = new System.Windows.Forms.TextBox();
            this.wordCountOutputTextBox = new System.Windows.Forms.TextBox();
            this.strToCharArrayGroupBox.SuspendLayout();
            this.dateToStringArrayTextBox.SuspendLayout();
            this.formatPhoneNumberGroupBox.SuspendLayout();
            this.reverseStringGroupBox.SuspendLayout();
            this.wordCountGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(1420, 471);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(80, 30);
            this.exitButton.TabIndex = 1;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // strToCharArrayGroupBox
            // 
            this.strToCharArrayGroupBox.Controls.Add(this.stringToCharArrayOutputTextBox);
            this.strToCharArrayGroupBox.Controls.Add(this.stringToCharArrayRichTextBox);
            this.strToCharArrayGroupBox.Controls.Add(this.strToCharArrayButton);
            this.strToCharArrayGroupBox.Controls.Add(this.strCharInstructionLabel);
            this.strToCharArrayGroupBox.Location = new System.Drawing.Point(12, 12);
            this.strToCharArrayGroupBox.Name = "strToCharArrayGroupBox";
            this.strToCharArrayGroupBox.Size = new System.Drawing.Size(291, 453);
            this.strToCharArrayGroupBox.TabIndex = 2;
            this.strToCharArrayGroupBox.TabStop = false;
            this.strToCharArrayGroupBox.Text = "String to Char Array";
            // 
            // stringToCharArrayRichTextBox
            // 
            this.stringToCharArrayRichTextBox.Location = new System.Drawing.Point(45, 175);
            this.stringToCharArrayRichTextBox.Name = "stringToCharArrayRichTextBox";
            this.stringToCharArrayRichTextBox.Size = new System.Drawing.Size(181, 96);
            this.stringToCharArrayRichTextBox.TabIndex = 2;
            this.stringToCharArrayRichTextBox.Text = "";
            // 
            // strToCharArrayButton
            // 
            this.strToCharArrayButton.Location = new System.Drawing.Point(92, 290);
            this.strToCharArrayButton.Name = "strToCharArrayButton";
            this.strToCharArrayButton.Size = new System.Drawing.Size(87, 32);
            this.strToCharArrayButton.TabIndex = 1;
            this.strToCharArrayButton.Text = "Convert";
            this.strToCharArrayButton.UseVisualStyleBackColor = true;
            this.strToCharArrayButton.Click += new System.EventHandler(this.strToCharArrayButton_Click);
            // 
            // strCharInstructionLabel
            // 
            this.strCharInstructionLabel.AutoSize = true;
            this.strCharInstructionLabel.Location = new System.Drawing.Point(41, 35);
            this.strCharInstructionLabel.Name = "strCharInstructionLabel";
            this.strCharInstructionLabel.Size = new System.Drawing.Size(185, 120);
            this.strCharInstructionLabel.TabIndex = 0;
            this.strCharInstructionLabel.Text = "Input a String and press \r\n\'Convert\' to convert it\r\nto an array of characters.\r\n\r" +
    "\nThey will be displayed as \r\nseparated with commas.";
            this.strCharInstructionLabel.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // dateToStringArrayTextBox
            // 
            this.dateToStringArrayTextBox.Controls.Add(this.formatDateOutputTextBox);
            this.dateToStringArrayTextBox.Controls.Add(this.dateFormatRichTextBox);
            this.dateToStringArrayTextBox.Controls.Add(this.dateToStringArrayButton);
            this.dateToStringArrayTextBox.Controls.Add(this.dateToArrayInstructionLabel);
            this.dateToStringArrayTextBox.Location = new System.Drawing.Point(309, 12);
            this.dateToStringArrayTextBox.Name = "dateToStringArrayTextBox";
            this.dateToStringArrayTextBox.Size = new System.Drawing.Size(291, 453);
            this.dateToStringArrayTextBox.TabIndex = 3;
            this.dateToStringArrayTextBox.TabStop = false;
            this.dateToStringArrayTextBox.Text = "Formatted Date to Array of Strings";
            // 
            // dateToStringArrayButton
            // 
            this.dateToStringArrayButton.Location = new System.Drawing.Point(89, 333);
            this.dateToStringArrayButton.Name = "dateToStringArrayButton";
            this.dateToStringArrayButton.Size = new System.Drawing.Size(87, 32);
            this.dateToStringArrayButton.TabIndex = 2;
            this.dateToStringArrayButton.Text = "Convert";
            this.dateToStringArrayButton.UseVisualStyleBackColor = true;
            this.dateToStringArrayButton.Click += new System.EventHandler(this.dateToStringArrayButton_Click);
            // 
            // dateToArrayInstructionLabel
            // 
            this.dateToArrayInstructionLabel.AutoSize = true;
            this.dateToArrayInstructionLabel.Location = new System.Drawing.Point(40, 35);
            this.dateToArrayInstructionLabel.Name = "dateToArrayInstructionLabel";
            this.dateToArrayInstructionLabel.Size = new System.Drawing.Size(199, 160);
            this.dateToArrayInstructionLabel.TabIndex = 0;
            this.dateToArrayInstructionLabel.Text = "Input a formatted date\r\nsuch as mm/dd/yyyy and\r\npress \'Convert\' to convert it\r\nto" +
    " an array of 3 Strings\r\n\r\nThey will be displayed as\r\n\"Month: (mm), Day: (dd), \r\n" +
    "Year: (yyyy)";
            this.dateToArrayInstructionLabel.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // formatPhoneNumberGroupBox
            // 
            this.formatPhoneNumberGroupBox.Controls.Add(this.phoneNumberOutputTextBox);
            this.formatPhoneNumberGroupBox.Controls.Add(this.phoneNumberFormatRichTextBox);
            this.formatPhoneNumberGroupBox.Controls.Add(this.phoneNumberFormatButton);
            this.formatPhoneNumberGroupBox.Controls.Add(this.phoneNumberFormatInstructionLabel);
            this.formatPhoneNumberGroupBox.Location = new System.Drawing.Point(606, 12);
            this.formatPhoneNumberGroupBox.Name = "formatPhoneNumberGroupBox";
            this.formatPhoneNumberGroupBox.Size = new System.Drawing.Size(291, 453);
            this.formatPhoneNumberGroupBox.TabIndex = 4;
            this.formatPhoneNumberGroupBox.TabStop = false;
            this.formatPhoneNumberGroupBox.Text = "Phone Number Formatter";
            // 
            // phoneNumberFormatButton
            // 
            this.phoneNumberFormatButton.Location = new System.Drawing.Point(110, 333);
            this.phoneNumberFormatButton.Name = "phoneNumberFormatButton";
            this.phoneNumberFormatButton.Size = new System.Drawing.Size(87, 32);
            this.phoneNumberFormatButton.TabIndex = 3;
            this.phoneNumberFormatButton.Text = "Convert";
            this.phoneNumberFormatButton.UseVisualStyleBackColor = true;
            this.phoneNumberFormatButton.Click += new System.EventHandler(this.phoneNumberFormatButton_Click);
            // 
            // phoneNumberFormatInstructionLabel
            // 
            this.phoneNumberFormatInstructionLabel.AutoSize = true;
            this.phoneNumberFormatInstructionLabel.Location = new System.Drawing.Point(45, 55);
            this.phoneNumberFormatInstructionLabel.Name = "phoneNumberFormatInstructionLabel";
            this.phoneNumberFormatInstructionLabel.Size = new System.Drawing.Size(196, 140);
            this.phoneNumberFormatInstructionLabel.TabIndex = 0;
            this.phoneNumberFormatInstructionLabel.Text = "Input a 10-character string\r\nand press \'Convert\' to\r\nconvert it to a formatted\r\np" +
    "hone number.\r\n\r\nIt will be displayed as\r\n(xxx) xxx-xxxx.";
            this.phoneNumberFormatInstructionLabel.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // reverseStringGroupBox
            // 
            this.reverseStringGroupBox.Controls.Add(this.reverseStringOutputTextBox);
            this.reverseStringGroupBox.Controls.Add(this.reverseStringRichTextBox);
            this.reverseStringGroupBox.Controls.Add(this.reverseStringButton);
            this.reverseStringGroupBox.Controls.Add(this.reverseInstructionLabel);
            this.reverseStringGroupBox.Location = new System.Drawing.Point(903, 12);
            this.reverseStringGroupBox.Name = "reverseStringGroupBox";
            this.reverseStringGroupBox.Size = new System.Drawing.Size(291, 453);
            this.reverseStringGroupBox.TabIndex = 5;
            this.reverseStringGroupBox.TabStop = false;
            this.reverseStringGroupBox.Text = "Reverse String";
            // 
            // reverseStringButton
            // 
            this.reverseStringButton.Location = new System.Drawing.Point(101, 239);
            this.reverseStringButton.Name = "reverseStringButton";
            this.reverseStringButton.Size = new System.Drawing.Size(87, 32);
            this.reverseStringButton.TabIndex = 4;
            this.reverseStringButton.Text = "Convert";
            this.reverseStringButton.UseVisualStyleBackColor = true;
            this.reverseStringButton.Click += new System.EventHandler(this.reverseStringButton_Click);
            // 
            // reverseInstructionLabel
            // 
            this.reverseInstructionLabel.AutoSize = true;
            this.reverseInstructionLabel.Location = new System.Drawing.Point(11, 55);
            this.reverseInstructionLabel.Name = "reverseInstructionLabel";
            this.reverseInstructionLabel.Size = new System.Drawing.Size(274, 40);
            this.reverseInstructionLabel.TabIndex = 0;
            this.reverseInstructionLabel.Text = "Input a String and press \'Convert\'\r\nto reverse the characters in the String";
            this.reverseInstructionLabel.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // wordCountGroupBox
            // 
            this.wordCountGroupBox.Controls.Add(this.wordCountOutputTextBox);
            this.wordCountGroupBox.Controls.Add(this.stringWordCountRichTextBox);
            this.wordCountGroupBox.Controls.Add(this.wordCountButton);
            this.wordCountGroupBox.Controls.Add(this.wordCountInstructionLabel);
            this.wordCountGroupBox.Location = new System.Drawing.Point(1209, 12);
            this.wordCountGroupBox.Name = "wordCountGroupBox";
            this.wordCountGroupBox.Size = new System.Drawing.Size(291, 453);
            this.wordCountGroupBox.TabIndex = 6;
            this.wordCountGroupBox.TabStop = false;
            this.wordCountGroupBox.Text = "String Word Count";
            // 
            // wordCountButton
            // 
            this.wordCountButton.Location = new System.Drawing.Point(107, 290);
            this.wordCountButton.Name = "wordCountButton";
            this.wordCountButton.Size = new System.Drawing.Size(87, 32);
            this.wordCountButton.TabIndex = 5;
            this.wordCountButton.Text = "Convert";
            this.wordCountButton.UseVisualStyleBackColor = true;
            this.wordCountButton.Click += new System.EventHandler(this.wordCountButton_Click);
            // 
            // wordCountInstructionLabel
            // 
            this.wordCountInstructionLabel.AutoSize = true;
            this.wordCountInstructionLabel.Location = new System.Drawing.Point(52, 55);
            this.wordCountInstructionLabel.Name = "wordCountInstructionLabel";
            this.wordCountInstructionLabel.Size = new System.Drawing.Size(202, 100);
            this.wordCountInstructionLabel.TabIndex = 0;
            this.wordCountInstructionLabel.Text = "Input a String with multiple\r\nwords separated by spaces\r\nand press \'Convert\' to\r\n" +
    "get the word count of\r\nyour string";
            this.wordCountInstructionLabel.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // dateFormatRichTextBox
            // 
            this.dateFormatRichTextBox.Location = new System.Drawing.Point(44, 220);
            this.dateFormatRichTextBox.Name = "dateFormatRichTextBox";
            this.dateFormatRichTextBox.Size = new System.Drawing.Size(181, 96);
            this.dateFormatRichTextBox.TabIndex = 3;
            this.dateFormatRichTextBox.Text = "";
            // 
            // phoneNumberFormatRichTextBox
            // 
            this.phoneNumberFormatRichTextBox.Location = new System.Drawing.Point(60, 220);
            this.phoneNumberFormatRichTextBox.Name = "phoneNumberFormatRichTextBox";
            this.phoneNumberFormatRichTextBox.Size = new System.Drawing.Size(181, 96);
            this.phoneNumberFormatRichTextBox.TabIndex = 4;
            this.phoneNumberFormatRichTextBox.Text = "";
            // 
            // reverseStringRichTextBox
            // 
            this.reverseStringRichTextBox.Location = new System.Drawing.Point(54, 117);
            this.reverseStringRichTextBox.Name = "reverseStringRichTextBox";
            this.reverseStringRichTextBox.Size = new System.Drawing.Size(181, 96);
            this.reverseStringRichTextBox.TabIndex = 5;
            this.reverseStringRichTextBox.Text = "";
            // 
            // stringWordCountRichTextBox
            // 
            this.stringWordCountRichTextBox.Location = new System.Drawing.Point(56, 175);
            this.stringWordCountRichTextBox.Name = "stringWordCountRichTextBox";
            this.stringWordCountRichTextBox.Size = new System.Drawing.Size(181, 96);
            this.stringWordCountRichTextBox.TabIndex = 6;
            this.stringWordCountRichTextBox.Text = "";
            // 
            // stringToCharArrayOutputTextBox
            // 
            this.stringToCharArrayOutputTextBox.Location = new System.Drawing.Point(45, 386);
            this.stringToCharArrayOutputTextBox.Name = "stringToCharArrayOutputTextBox";
            this.stringToCharArrayOutputTextBox.Size = new System.Drawing.Size(181, 26);
            this.stringToCharArrayOutputTextBox.TabIndex = 3;
            // 
            // formatDateOutputTextBox
            // 
            this.formatDateOutputTextBox.Location = new System.Drawing.Point(44, 399);
            this.formatDateOutputTextBox.Name = "formatDateOutputTextBox";
            this.formatDateOutputTextBox.Size = new System.Drawing.Size(181, 26);
            this.formatDateOutputTextBox.TabIndex = 4;
            // 
            // phoneNumberOutputTextBox
            // 
            this.phoneNumberOutputTextBox.Location = new System.Drawing.Point(60, 399);
            this.phoneNumberOutputTextBox.Name = "phoneNumberOutputTextBox";
            this.phoneNumberOutputTextBox.Size = new System.Drawing.Size(181, 26);
            this.phoneNumberOutputTextBox.TabIndex = 5;
            // 
            // reverseStringOutputTextBox
            // 
            this.reverseStringOutputTextBox.Location = new System.Drawing.Point(54, 296);
            this.reverseStringOutputTextBox.Name = "reverseStringOutputTextBox";
            this.reverseStringOutputTextBox.Size = new System.Drawing.Size(181, 26);
            this.reverseStringOutputTextBox.TabIndex = 6;
            // 
            // wordCountOutputTextBox
            // 
            this.wordCountOutputTextBox.Location = new System.Drawing.Point(56, 363);
            this.wordCountOutputTextBox.Name = "wordCountOutputTextBox";
            this.wordCountOutputTextBox.Size = new System.Drawing.Size(181, 26);
            this.wordCountOutputTextBox.TabIndex = 7;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1510, 511);
            this.Controls.Add(this.wordCountGroupBox);
            this.Controls.Add(this.reverseStringGroupBox);
            this.Controls.Add(this.formatPhoneNumberGroupBox);
            this.Controls.Add(this.dateToStringArrayTextBox);
            this.Controls.Add(this.strToCharArrayGroupBox);
            this.Controls.Add(this.exitButton);
            this.Name = "Form1";
            this.Text = "String Extension Methods";
            this.strToCharArrayGroupBox.ResumeLayout(false);
            this.strToCharArrayGroupBox.PerformLayout();
            this.dateToStringArrayTextBox.ResumeLayout(false);
            this.dateToStringArrayTextBox.PerformLayout();
            this.formatPhoneNumberGroupBox.ResumeLayout(false);
            this.formatPhoneNumberGroupBox.PerformLayout();
            this.reverseStringGroupBox.ResumeLayout(false);
            this.reverseStringGroupBox.PerformLayout();
            this.wordCountGroupBox.ResumeLayout(false);
            this.wordCountGroupBox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.GroupBox strToCharArrayGroupBox;
        private System.Windows.Forms.Label strCharInstructionLabel;
        private System.Windows.Forms.GroupBox dateToStringArrayTextBox;
        private System.Windows.Forms.GroupBox formatPhoneNumberGroupBox;
        private System.Windows.Forms.GroupBox reverseStringGroupBox;
        private System.Windows.Forms.GroupBox wordCountGroupBox;
        private System.Windows.Forms.Label dateToArrayInstructionLabel;
        private System.Windows.Forms.Label phoneNumberFormatInstructionLabel;
        private System.Windows.Forms.Label reverseInstructionLabel;
        private System.Windows.Forms.Label wordCountInstructionLabel;
        private System.Windows.Forms.Button strToCharArrayButton;
        private System.Windows.Forms.Button dateToStringArrayButton;
        private System.Windows.Forms.Button phoneNumberFormatButton;
        private System.Windows.Forms.Button wordCountButton;
        private System.Windows.Forms.Button reverseStringButton;
        private System.Windows.Forms.RichTextBox stringToCharArrayRichTextBox;
        private System.Windows.Forms.RichTextBox dateFormatRichTextBox;
        private System.Windows.Forms.RichTextBox phoneNumberFormatRichTextBox;
        private System.Windows.Forms.RichTextBox reverseStringRichTextBox;
        private System.Windows.Forms.RichTextBox stringWordCountRichTextBox;
        private System.Windows.Forms.TextBox stringToCharArrayOutputTextBox;
        private System.Windows.Forms.TextBox formatDateOutputTextBox;
        private System.Windows.Forms.TextBox phoneNumberOutputTextBox;
        private System.Windows.Forms.TextBox reverseStringOutputTextBox;
        private System.Windows.Forms.TextBox wordCountOutputTextBox;
    }
}


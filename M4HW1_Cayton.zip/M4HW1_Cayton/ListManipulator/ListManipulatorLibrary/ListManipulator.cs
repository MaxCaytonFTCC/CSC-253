﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ListManipulatorLibrary
{
    public static class ListManipulator
    {
        
        public static List<int> LoadIntegerList()        
        {
            // Returns a list of ints from the random.txt file
            List<int> randomInts = new List<int>();

            using (StreamReader reader = File.OpenText(@"../../../ListManipulatorLibrary/Docs/random.txt"))
            {
                while (!reader.EndOfStream)
                {
                    randomInts.Add(int.Parse(reader.ReadLine()));
                }
            }

            return randomInts;
        }
        
        public static void RemoveNegatives(List<int> list)
        {
            // Removes all negatives from provided list
            Predicate<int> isNegative = x => x < 0;
            list.RemoveAll(isNegative);            
        }

        public static List<int> GetWithinRange(List<int> list)
        {
            // Returns a list with values in the 1-10 range only
            List<int> newList = new List<int>();
            Predicate<int> isWithinRange = x => (x >= 1 && x <= 10);
            newList = list.FindAll(isWithinRange);
            return newList;
        }

    }
}

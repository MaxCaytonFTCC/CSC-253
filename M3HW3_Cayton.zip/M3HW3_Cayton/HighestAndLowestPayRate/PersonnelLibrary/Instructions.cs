﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PersonnelLibrary
{
    public static class Instructions
    {
        public static void DisplayInstructions()
        {
            MessageBox.Show("Enter an employee's name in the textbox and press \"Search\" to find all rows that contain a full or partial match.\n\nPress \"Display All\" to go back to displaying the whole table." +
                "\n\nAdditionally, press either \"Display Highest Pay Rate\" or \"Display Lowest Pay Rate\" to view the respective pay rate extrema.");
        }

    }
}

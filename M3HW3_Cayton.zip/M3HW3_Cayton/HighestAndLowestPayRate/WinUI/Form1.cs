﻿/**
* 10/16/2023
* CSC 253
* Max Cayton
* This program displays the Personel Database's Employee Table and allows the user to search for employee names and display the highest and lowest pay rates in the table.
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PersonnelLibrary;

namespace WinUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'personnelDataSet.Employee' table. You can move, or remove it, as needed.
            this.employeeTableAdapter.Fill(this.personnelDataSet.Employee);

        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void instructionsButton_Click(object sender, EventArgs e)
        {
            // Display Instructions
            Instructions.DisplayInstructions();
        }

        private void searchButton_Click(object sender, EventArgs e)
        {            
            this.employeeTableAdapter.NameSearch(this.personnelDataSet.Employee,searchTextBox.Text);
        }

        private void displayAllButton_Click(object sender, EventArgs e)
        {
            this.employeeTableAdapter.Fill(this.personnelDataSet.Employee);
        }

        private void highestPayRateButton_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Highest Pay Rate in the Employees Table: "+this.employeeTableAdapter.GetMaxPayRate().ToString());
        }

        private void lowestPayRateButton_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Lowest Pay Rate in the Employees Table: " + this.employeeTableAdapter.GetMinPayRate().ToString());
        }
    }
}

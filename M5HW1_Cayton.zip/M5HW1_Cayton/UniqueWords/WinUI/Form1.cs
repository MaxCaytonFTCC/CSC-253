﻿/**
* 11/6/2023
* CSC 253
* Max Cayton
* This program takes a text file containing 101 fruit names and can either display the contents of the file normally, or remove all duplicate entries then display the results
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WordLibrary;

namespace WinUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void fullFileButton_Click(object sender, EventArgs e)
        {
            // Display the the normal contents of the file
            SetListBox(wordListBox,UniqueWord.GetWordsFromFile());
        }

        private void uniqueButton_Click(object sender, EventArgs e)
        {
            // Only display unique words
            List<string> uniqueWords = UniqueWord.RemoveDuplicates(UniqueWord.GetWordsFromFile());
            SetListBox(wordListBox, uniqueWords);
        }

        private void SetListBox(ListBox listBox, List<string> words)
        {
            // Method for setting the ListBox to a list
            wordListBox.Items.Clear();            
            foreach (string word in words)            
                wordListBox.Items.Add(word);            
        }
    }
}

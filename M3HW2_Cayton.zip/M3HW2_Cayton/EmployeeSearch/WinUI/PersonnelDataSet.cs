﻿namespace WinUI
{


    partial class PersonnelDataSet
    {
    }
}






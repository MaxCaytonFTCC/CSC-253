﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace GasLibrary
{
    public static class GasPriceOperations
    {


        public static List<GasPrice> ReadGasPricesFile()
        {

            List<GasPrice> prices = new List<GasPrice>();

            using (StreamReader reader = File.OpenText(@"../../../GasLibrary/GasPrices.txt"))
            {
                while (!reader.EndOfStream)
                {
                    string[] tokens = reader.ReadLine().Split(':');
                    prices.Add(new GasPrice(DateTime.Parse(tokens[0]), double.Parse(tokens[1]) ));
                   
                }
            }

            return prices;

        }

        public static double GetAveragePricePerYear(int year)
        {
            // Returns the average gas price for a given year

            List<GasPrice> gasPrices = ReadGasPricesFile();

            Predicate<GasPrice> isDifferentYear = x => x.Date.Year != year; // For checking if the years match

            gasPrices.RemoveAll(isDifferentYear); // Remove all entries that aren't on the specified year

            List<double> prices = GetPriceList(gasPrices); // Get the prices within that year

            return prices.Average(); // Return the average

        }

        public static double GetAveragePricePerMonth(int month, int year=-1)
        {
            // Returns either the average price for the specified month across all years (if year is -1)
            // or within a specified year (if year is a specifed year)

            Predicate<GasPrice> isDifferentYear = x => x.Date.Year != year; // For checking if the years match
            Predicate<GasPrice> isDifferentMonth = x => x.Date.Month != month; // For checking if the months match

            List<GasPrice> gasPrices = ReadGasPricesFile();

            if (year != -1) gasPrices.RemoveAll(isDifferentYear); // Remove all entries that aren't on the specified year

            gasPrices.RemoveAll(isDifferentMonth); // Remove all entries that aren't on the specified month

            List<double> prices = GetPriceList(gasPrices); // Get the prices within that month

            return prices.Average(); // Return the average                
                     
        }

        public static GasPrice GetHighestPrice()
        {
            // Gets the entry with highest price across all years

            List<GasPrice> gasPrices = ReadGasPricesFile();

            List<double> prices = GetPriceList(gasPrices);

            double maxPrice = prices.Max();

            Predicate<GasPrice> hasMaxValue = x => x.Price == maxPrice;

            return gasPrices.ElementAt(gasPrices.FindIndex(hasMaxValue));               

        }

        public static GasPrice GetLowestPrice()
        {
            // Gets the entry with lowest price across all years

            List<GasPrice> gasPrices = ReadGasPricesFile();

            List<double> prices = GetPriceList(gasPrices);

            double minPrice = prices.Min();

            Predicate<GasPrice> hasMinValue = x => x.Price == minPrice;

            return gasPrices.ElementAt(gasPrices.FindIndex(hasMinValue));              

        }

        public static void GenerateAscendingTextFile()
        {
            // Outputs the Gas Prices to a file in Ascending Order
            StreamWriter outputFile;
            
            outputFile = File.CreateText(@"..\..\..\GasLibrary\OutputFiles\Ascending\GasPricesAscending.txt");

            // Get Ascending List
            List<GasPrice> gasPrices = ReadGasPricesFile().OrderBy(gasPrice => gasPrice.Price).ToList(); 
            
            // Output
            foreach (GasPrice gasPrice in gasPrices)
            {
                outputFile.WriteLine($"{gasPrice.Date.ToString("d")}:{gasPrice.Price}");
            }

            outputFile.Close();

        }

        public static void GenerateDescendingTextFile()
        {
            // Outputs the Gas Prices to a file in Descending Order
            StreamWriter outputFile;

            outputFile = File.CreateText(@"..\..\..\GasLibrary\OutputFiles\Descending\GasPricesDescending.txt");

            // Get Ascending List
            List<GasPrice> gasPrices = ReadGasPricesFile().OrderByDescending(gasPrice => gasPrice.Price).ToList();

            // Output
            foreach (GasPrice gasPrice in gasPrices)
            {
                outputFile.WriteLine($"{gasPrice.Date.ToString("d")}:{gasPrice.Price}");
            }

            outputFile.Close();

        }

        private static List<double> GetPriceList(List<GasPrice> gasPrices)
        {
            // Gets a list of the prices held in the GasPrices list for ease of use with list methods
            List<double> prices = new List<double>();

            for (int i = 0; i < gasPrices.Count; i++)
            {
                prices.Add(gasPrices.ElementAt(i).Price);
            }

            return prices;

        }

    }
}

﻿/**
* 9/25/2023
* CSC 253
* Max Cayton
* This program displays the properties of an object created from the derived TeamLeader class 
* and allows the user to change & display their values
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using EmployeeLibrary;

namespace WinUI
{
    public partial class Form1 : Form
    {
        TeamLeader worker = new TeamLeader(); // Create Object of TeamLeader for application
        public Form1()
        {
            InitializeComponent();

            // Display defualt values for each property
            DisplayProperties();

        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();            
        }

        private void DisplayProperties()
        {
            // Employee Properties
            outputNameTextBox.Text = worker.Name;
            outputNumberTextBox.Text = worker.Number.ToString();
            
            // Production Worker Properties
            outputShiftNumberTextBox.Text = worker.ShiftNumber.ToString();
            outputHourlyPayTextBox.Text = worker.HourlyPayRate.ToString("c");

            // Team Leader Properties
            outputMonthlyBonusTextBox.Text = worker.MonthlyBonusAmount.ToString("c"); 
            outputRequiredHoursTextBox.Text = worker.RequiredTrainingHours.ToString();
            outputTrainingHoursTextBox.Text = worker.NumTrainingHours.ToString();
        }

        private void submitButton_Click(object sender, EventArgs e)
        {
            try
            {
                worker.Name = nameTextBox.Text;
                worker.Number = int.Parse(numberTextBox.Text);
                worker.ShiftNumber = int.Parse(shiftNumberTextBox.Text);
                worker.HourlyPayRate = decimal.Parse(hourlyPayTextBox.Text);
                worker.MonthlyBonusAmount = decimal.Parse(monthlyBonusTextBox.Text);
                worker.RequiredTrainingHours = int.Parse(requiredHoursTextBox.Text);
                worker.NumTrainingHours = int.Parse(trainingHoursTextBox.Text);
                DisplayProperties();
            }
            catch 
            {
                MessageBox.Show("Invalid Input, Please Try Again.");
            }
        }

        private void clearButton_Click(object sender, EventArgs e)
        {                
            nameTextBox.Clear();
            numberTextBox.Clear();
            shiftNumberTextBox.Clear();
            hourlyPayTextBox.Clear();
            monthlyBonusTextBox.Clear();
            requiredHoursTextBox.Clear();
            trainingHoursTextBox.Clear();
            outputNameTextBox.Clear();
            outputNumberTextBox.Clear();
            outputShiftNumberTextBox.Clear();
            outputHourlyPayTextBox.Clear();
            outputMonthlyBonusTextBox.Clear();
            outputRequiredHoursTextBox.Clear();
            outputTrainingHoursTextBox.Clear();
        }

        private void displayButton_Click(object sender, EventArgs e)
        {
            DisplayProperties();
        }

    }
}

﻿namespace WinUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.wordListBox = new System.Windows.Forms.ListBox();
            this.exitButton = new System.Windows.Forms.Button();
            this.fullFileButton = new System.Windows.Forms.Button();
            this.uniqueButton = new System.Windows.Forms.Button();
            this.wordListLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // wordListBox
            // 
            this.wordListBox.FormattingEnabled = true;
            this.wordListBox.ItemHeight = 20;
            this.wordListBox.Location = new System.Drawing.Point(280, 60);
            this.wordListBox.Name = "wordListBox";
            this.wordListBox.Size = new System.Drawing.Size(391, 744);
            this.wordListBox.TabIndex = 0;            
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(597, 824);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(74, 35);
            this.exitButton.TabIndex = 1;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // fullFileButton
            // 
            this.fullFileButton.Location = new System.Drawing.Point(51, 294);
            this.fullFileButton.Name = "fullFileButton";
            this.fullFileButton.Size = new System.Drawing.Size(182, 44);
            this.fullFileButton.TabIndex = 2;
            this.fullFileButton.Text = "Display Full File";
            this.fullFileButton.UseVisualStyleBackColor = true;
            this.fullFileButton.Click += new System.EventHandler(this.fullFileButton_Click);
            // 
            // uniqueButton
            // 
            this.uniqueButton.Location = new System.Drawing.Point(51, 449);
            this.uniqueButton.Name = "uniqueButton";
            this.uniqueButton.Size = new System.Drawing.Size(182, 53);
            this.uniqueButton.TabIndex = 3;
            this.uniqueButton.Text = "Display Unique Words Only";
            this.uniqueButton.UseVisualStyleBackColor = true;
            this.uniqueButton.Click += new System.EventHandler(this.uniqueButton_Click);
            // 
            // wordListLabel
            // 
            this.wordListLabel.AutoSize = true;
            this.wordListLabel.Location = new System.Drawing.Point(426, 37);
            this.wordListLabel.Name = "wordListLabel";
            this.wordListLabel.Size = new System.Drawing.Size(100, 20);
            this.wordListLabel.TabIndex = 4;
            this.wordListLabel.Text = "Words in File";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(708, 879);
            this.Controls.Add(this.wordListLabel);
            this.Controls.Add(this.uniqueButton);
            this.Controls.Add(this.fullFileButton);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.wordListBox);
            this.Name = "Form1";
            this.Text = "Unique Words";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox wordListBox;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Button fullFileButton;
        private System.Windows.Forms.Button uniqueButton;
        private System.Windows.Forms.Label wordListLabel;
    }
}


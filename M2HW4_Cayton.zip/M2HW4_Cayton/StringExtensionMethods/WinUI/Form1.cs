﻿/**
* 9/25/2023
* CSC 253
* Max Cayton
* This program allows the user to either convert a string to an array of characters, format a date, format a phone number,
* reverse a string, or get the number of words in a string.
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using StringExtensionLibrary;

namespace WinUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
            
        }

        private void strToCharArrayButton_Click(object sender, EventArgs e)
        {
            // Perform Conversion
            char[] charArray = stringToCharArrayRichTextBox.Text.ToCharacterArray();
            // Display Result
            stringToCharArrayOutputTextBox.Clear();
            int charIndex = 0;
            foreach (char c in charArray)
            {
                if (charIndex == charArray.Length-1) stringToCharArrayOutputTextBox.Text += c.ToString();
                else stringToCharArrayOutputTextBox.Text += c.ToString() + ", ";
                charIndex++;
            }

        }

        private void dateToStringArrayButton_Click(object sender, EventArgs e)
        {
            // Perform Conversion
            string[] dateArray = dateFormatRichTextBox.Text.ToDateArray();
            // Display Result
            if (dateArray == null) formatDateOutputTextBox.Text = "Invalid Date";
            else
            {
                formatDateOutputTextBox.Clear();
                for (int i = 0; i < dateArray.Length; i++)
                {
                    switch (i)
                    {
                        case 0:
                            formatDateOutputTextBox.Text += "Month: " + dateArray[i] + ", ";
                            break;

                        case 1:
                            formatDateOutputTextBox.Text += "Day: " + dateArray[i] + ", ";
                            break;

                        case 2:
                            formatDateOutputTextBox.Text += "Year: " + dateArray[i];
                            break;
                    }
                }
            }
        }

        private void phoneNumberFormatButton_Click(object sender, EventArgs e)
        {
            // Perform Conversion
            string formattedPhoneNumber = phoneNumberFormatRichTextBox.Text.ToPhoneNumber();
            // Display Result
            phoneNumberOutputTextBox.Clear();
            phoneNumberOutputTextBox.Text = formattedPhoneNumber;
        }

        private void reverseStringButton_Click(object sender, EventArgs e)
        {
            // Perform Conversion & Display Result
            reverseStringOutputTextBox.Text = reverseStringRichTextBox.Text.ToReverse();
        }

        private void wordCountButton_Click(object sender, EventArgs e)
        {
            // Perform Conversion
            int wordCount = stringWordCountRichTextBox.Text.GetWordCount();
            wordCountOutputTextBox.Clear();

            if (wordCount == -1) wordCountOutputTextBox.Text = "Newlines Not Supported";
            else wordCountOutputTextBox.Text = "Word Count: " + wordCount.ToString();
        }
    }
}

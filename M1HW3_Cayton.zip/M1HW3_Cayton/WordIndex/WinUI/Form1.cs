﻿/**
* 9/12/2023
* CSC 253
* Max Cayton
* This program creates a word index file for a given input file that shows on which lines each word appears on.
*/
using IndexLibrary;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;


namespace WinUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();            
        }

        #region Input File Controls
        private void readButton_Click(object sender, EventArgs e)
        {
            StreamReader inputFile;

            // Open File
            inputFile = File.OpenText(@"../../../IndexLibrary/Docs/sample_text.txt");

            // Display File Contents
            inputRichTextBox.Clear();
            inputRichTextBox.Text = inputFile.ReadToEnd();

            inputFile.Close();
        }

        private void writeButton_Click(object sender, EventArgs e)
        {
            StreamWriter outputFile;
            // Open File
            outputFile = File.CreateText(@"../../../IndexLibrary/Docs/sample_text.txt");

            // Write File Contents            
            outputFile.Write(inputRichTextBox.Text);
            outputFile.Close();
        }
        #endregion

        #region Word Index File Controls
        private void wordIndexReadButton_Click(object sender, EventArgs e)
        {
            StreamReader inputFile;

            // Open File
            inputFile = File.OpenText(@"../../../IndexLibrary/Docs/word_index.txt");

            // Display File Contents
            wordIndexRichTextBox.Clear();
            wordIndexRichTextBox.Text = inputFile.ReadToEnd();

            inputFile.Close();
        }

        private void wordIndexWriteButton_Click(object sender, EventArgs e)
        {
            StreamWriter outputFile;
            // Open File
            outputFile = File.CreateText(@"../../../IndexLibrary/Docs/word_index.txt");

            // Write File Contents            
            outputFile.Write(wordIndexRichTextBox.Text);
            outputFile.Close();
        }
        #endregion

        
        private void indexButton_Click(object sender, EventArgs e)
        {
            Index.CreateIndex("../../../IndexLibrary/Docs/sample_text.txt", "../../../IndexLibrary/Docs/word_index.txt");

            StreamReader inputFile;

            // Open File
            inputFile = File.OpenText(@"../../../IndexLibrary/Docs/word_index.txt");

            // Display File Contents
            wordIndexRichTextBox.Clear();
            wordIndexRichTextBox.Text = inputFile.ReadToEnd();
            

            inputFile.Close();

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PersonnelLibrary
{
    public static class Instructions
    {
        public static void DisplayInstructions()
        {
            MessageBox.Show("Use the Data Grid View control to manage & view the Personnel Database\n\nNote: Support for Employee Searching will be available in the next assignment.");
        }

    }
}

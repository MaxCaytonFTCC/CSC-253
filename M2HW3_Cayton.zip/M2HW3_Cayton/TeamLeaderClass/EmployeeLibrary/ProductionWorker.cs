﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeLibrary
{
    public class ProductionWorker : Employee
    {
        public ProductionWorker() // Default Constructor
        {   
            // Default Values
            shiftNumber = 0;
            ShiftNumber = shiftNumber;
            HourlyPayRate = 0.0m;

        } 

        private int shiftNumber; // Backing field
        public int ShiftNumber 
        { 
            get { return shiftNumber; }
            set { 
                if (value == 1 || value == 2) // Only allow valid entries
                {
                    shiftNumber = value;
                }
                else
                {
                    shiftNumber = 1; // Default value to 1
                }
            } 
        }
        public decimal HourlyPayRate { get; set; }

    }
}

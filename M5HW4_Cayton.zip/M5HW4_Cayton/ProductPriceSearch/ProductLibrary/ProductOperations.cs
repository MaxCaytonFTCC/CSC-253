﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductLibrary
{
    public static class ProductOperations
    {

        public static List<Product> GetProductNumberResults(string searchNumber)
        {

            // Searches the DB for the specified number

            List<Product> resultsList = new List<Product>();

            ProductDataClassesDataContext db = new ProductDataClassesDataContext();

            var results = from product in db.Products
                          where product.Product_Number == searchNumber
                          select product;

            resultsList = results.ToList();

            return resultsList;
        }

        public static List<Product> GetProductDescResults(string searchDesc)
        {

            // Searches the DB for descriptions containing the specified description text

            List<Product> resultsList = new List<Product>();

            ProductDataClassesDataContext db = new ProductDataClassesDataContext();

            var results = from product in db.Products
                          where product.Description.Contains(searchDesc)
                          select product;

            resultsList = results.ToList();

            return resultsList;
        }

        public static List<Product> GetProductPriceAscending()
        {

            // Sorts the products in ascending order by price

            List<Product> resultsList = new List<Product>();

            ProductDataClassesDataContext db = new ProductDataClassesDataContext();

            var results = from product in db.Products
                          orderby product.Price
                          select product;

            resultsList = results.ToList();

            return resultsList;
        }

        public static List<Product> GetProductPriceRange(decimal minPrice, decimal maxPrice)
        {

            // Sorts the products in ascending order by price

            List<Product> resultsList = new List<Product>();

            ProductDataClassesDataContext db = new ProductDataClassesDataContext();

            var results = from product in db.Products
                          orderby product.Price
                          where product.Price >= minPrice && product.Price <= maxPrice
                          select product;

            resultsList = results.ToList();

            return resultsList;
        }

    }
}

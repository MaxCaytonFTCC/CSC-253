﻿/**
* 11/2/2023
* CSC 253
* Max Cayton
* This program allows the user to apply 1 of 3 criteria to a list of English surnames and view the results.
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SurnameLibrary;

namespace WinUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();            
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void longerButton_Click(object sender, EventArgs e)
        {
            // Apply Longer-Than Filter
            try
            { 
            SetListBox(namesListBox, NameFilter.FilterNamesLongerThan(NameFilter.GetNamesFromFile(), int.Parse(longerTextBox.Text)));
            }
            catch
            {
                
                MessageBox.Show("Something went wrong... Please try again");
            }
        }

        private void shorterButton_Click(object sender, EventArgs e)
        {
            // Apply Shorter-Than Filter
            try
            {
                SetListBox(namesListBox, NameFilter.FilterNamesShorterThan(NameFilter.GetNamesFromFile(), int.Parse(shorterTextBox.Text)));
            }
            catch
            {
                MessageBox.Show("Something went wrong... Please try again");
            }
        }

        private void beginsButton_Click(object sender, EventArgs e)
        {
            // Apply Begins-With Filter
            try
            {
                SetListBox(namesListBox, NameFilter.FilterNamesBeginsWith(NameFilter.GetNamesFromFile(), beginsTextBox.Text));
            }
            catch
            {
                MessageBox.Show("Something went wrong... Please try again");
            }
        }

        private void noFilterButton_Click(object sender, EventArgs e)
        {
            // Displays the names without any filters (the full file)
            SetListBox(namesListBox,NameFilter.GetNamesFromFile());
        }

        private void SetListBox(ListBox listBox, List<string> names)
        {
            listBox.Items.Clear();
            foreach (string name in names)
            {
                listBox.Items.Add(name);
            }
        }
        
    }
}

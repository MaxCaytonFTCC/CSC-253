﻿namespace WinUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.exitButton = new System.Windows.Forms.Button();
            this.inputFileGroupBox = new System.Windows.Forms.GroupBox();
            this.wordIndexGroupBox = new System.Windows.Forms.GroupBox();
            this.indexButton = new System.Windows.Forms.Button();
            this.instructionLabel = new System.Windows.Forms.Label();
            this.inputRichTextBox = new System.Windows.Forms.RichTextBox();
            this.wordIndexRichTextBox = new System.Windows.Forms.RichTextBox();
            this.readButton = new System.Windows.Forms.Button();
            this.writeButton = new System.Windows.Forms.Button();
            this.wordIndexWriteButton = new System.Windows.Forms.Button();
            this.wordIndexReadButton = new System.Windows.Forms.Button();
            this.inputFileGroupBox.SuspendLayout();
            this.wordIndexGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(1356, 973);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(95, 37);
            this.exitButton.TabIndex = 0;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // inputFileGroupBox
            // 
            this.inputFileGroupBox.Controls.Add(this.writeButton);
            this.inputFileGroupBox.Controls.Add(this.readButton);
            this.inputFileGroupBox.Controls.Add(this.inputRichTextBox);
            this.inputFileGroupBox.Location = new System.Drawing.Point(43, 129);
            this.inputFileGroupBox.Name = "inputFileGroupBox";
            this.inputFileGroupBox.Size = new System.Drawing.Size(635, 752);
            this.inputFileGroupBox.TabIndex = 1;
            this.inputFileGroupBox.TabStop = false;
            this.inputFileGroupBox.Text = "Input File";
            // 
            // wordIndexGroupBox
            // 
            this.wordIndexGroupBox.Controls.Add(this.wordIndexWriteButton);
            this.wordIndexGroupBox.Controls.Add(this.wordIndexReadButton);
            this.wordIndexGroupBox.Controls.Add(this.wordIndexRichTextBox);
            this.wordIndexGroupBox.Location = new System.Drawing.Point(773, 129);
            this.wordIndexGroupBox.Name = "wordIndexGroupBox";
            this.wordIndexGroupBox.Size = new System.Drawing.Size(635, 752);
            this.wordIndexGroupBox.TabIndex = 2;
            this.wordIndexGroupBox.TabStop = false;
            this.wordIndexGroupBox.Text = "Word Index";
            // 
            // indexButton
            // 
            this.indexButton.Location = new System.Drawing.Point(684, 458);
            this.indexButton.Name = "indexButton";
            this.indexButton.Size = new System.Drawing.Size(83, 39);
            this.indexButton.TabIndex = 3;
            this.indexButton.Text = "Index";
            this.indexButton.UseVisualStyleBackColor = true;
            this.indexButton.Click += new System.EventHandler(this.indexButton_Click);
            // 
            // instructionLabel
            // 
            this.instructionLabel.AutoSize = true;
            this.instructionLabel.Location = new System.Drawing.Point(143, 65);
            this.instructionLabel.Name = "instructionLabel";
            this.instructionLabel.Size = new System.Drawing.Size(1141, 20);
            this.instructionLabel.TabIndex = 4;
            this.instructionLabel.Text = "Press \"Read\" to view the contents of one of the files, press \"Write\" to save any " +
    "changes made to them, and press \"Index\" to create a Word Index for the input fil" +
    "e.\r\n";
            // 
            // inputRichTextBox
            // 
            this.inputRichTextBox.Location = new System.Drawing.Point(7, 26);
            this.inputRichTextBox.Name = "inputRichTextBox";
            this.inputRichTextBox.Size = new System.Drawing.Size(622, 668);
            this.inputRichTextBox.TabIndex = 0;
            this.inputRichTextBox.Text = "";
            // 
            // wordIndexRichTextBox
            // 
            this.wordIndexRichTextBox.Location = new System.Drawing.Point(0, 26);
            this.wordIndexRichTextBox.Name = "wordIndexRichTextBox";
            this.wordIndexRichTextBox.Size = new System.Drawing.Size(629, 668);
            this.wordIndexRichTextBox.TabIndex = 0;
            this.wordIndexRichTextBox.Text = "";
            // 
            // readButton
            // 
            this.readButton.Location = new System.Drawing.Point(7, 700);
            this.readButton.Name = "readButton";
            this.readButton.Size = new System.Drawing.Size(82, 46);
            this.readButton.TabIndex = 1;
            this.readButton.Text = "Read";
            this.readButton.UseVisualStyleBackColor = true;
            this.readButton.Click += new System.EventHandler(this.readButton_Click);
            // 
            // writeButton
            // 
            this.writeButton.Location = new System.Drawing.Point(547, 700);
            this.writeButton.Name = "writeButton";
            this.writeButton.Size = new System.Drawing.Size(82, 46);
            this.writeButton.TabIndex = 2;
            this.writeButton.Text = "Write";
            this.writeButton.UseVisualStyleBackColor = true;
            this.writeButton.Click += new System.EventHandler(this.writeButton_Click);
            // 
            // wordIndexWriteButton
            // 
            this.wordIndexWriteButton.Location = new System.Drawing.Point(547, 700);
            this.wordIndexWriteButton.Name = "wordIndexWriteButton";
            this.wordIndexWriteButton.Size = new System.Drawing.Size(82, 46);
            this.wordIndexWriteButton.TabIndex = 4;
            this.wordIndexWriteButton.Text = "Write";
            this.wordIndexWriteButton.UseVisualStyleBackColor = true;
            this.wordIndexWriteButton.Click += new System.EventHandler(this.wordIndexWriteButton_Click);
            // 
            // wordIndexReadButton
            // 
            this.wordIndexReadButton.Location = new System.Drawing.Point(7, 700);
            this.wordIndexReadButton.Name = "wordIndexReadButton";
            this.wordIndexReadButton.Size = new System.Drawing.Size(82, 46);
            this.wordIndexReadButton.TabIndex = 3;
            this.wordIndexReadButton.Text = "Read";
            this.wordIndexReadButton.UseVisualStyleBackColor = true;
            this.wordIndexReadButton.Click += new System.EventHandler(this.wordIndexReadButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1463, 1022);
            this.Controls.Add(this.instructionLabel);
            this.Controls.Add(this.indexButton);
            this.Controls.Add(this.wordIndexGroupBox);
            this.Controls.Add(this.inputFileGroupBox);
            this.Controls.Add(this.exitButton);
            this.Name = "Form1";
            this.Text = "Word Index";
            this.inputFileGroupBox.ResumeLayout(false);
            this.wordIndexGroupBox.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.GroupBox inputFileGroupBox;
        private System.Windows.Forms.RichTextBox inputRichTextBox;
        private System.Windows.Forms.GroupBox wordIndexGroupBox;
        private System.Windows.Forms.Button indexButton;
        private System.Windows.Forms.Label instructionLabel;
        private System.Windows.Forms.Button writeButton;
        private System.Windows.Forms.Button readButton;
        private System.Windows.Forms.Button wordIndexWriteButton;
        private System.Windows.Forms.Button wordIndexReadButton;
        private System.Windows.Forms.RichTextBox wordIndexRichTextBox;
    }
}


﻿/**
* 11/13/2023
* CSC 253
* Max Cayton
* This program reads the date and price values from a text file of gas prices and allows the user to perform operations on them.
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using GasLibrary;

namespace WinUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {            
            this.Close();
        }

        #region Average Price Per Year
        private void displayYearButton_Click(object sender, EventArgs e)
        {
            try
            {
                // Display Average Price Per Year
                MessageBox.Show(GasPriceOperations.GetAveragePricePerYear(int.Parse(yearTextBox.Text)).ToString());

            }
            catch 
            {
                MessageBox.Show("Something went wrong... Please try again.");
            }
        }
        #endregion

        #region Average Price Per Month
        private void displayMonthButton_Click(object sender, EventArgs e)
        {
            try
            {
                // Display Average Price Per Year
                int year = (monthYearTextBox.Text != "") ? int.Parse(monthYearTextBox.Text) : -1;
                MessageBox.Show(GasPriceOperations.GetAveragePricePerMonth(int.Parse(monthTextBox.Text), year).ToString());

            }
            catch
            {
                MessageBox.Show("Something went wrong... Please try again.");
            }
        }
        #endregion

        #region Highest & Lowest Prices Per Year
        private void highestButton_Click(object sender, EventArgs e)
        {
            // Display Date & Price of the highest gas price
            GasPrice highestPrice = GasPriceOperations.GetHighestPrice();
            MessageBox.Show( $"Date: {highestPrice.Date.ToString("d")}, Price: {highestPrice.Price}");
        }

        private void lowestButton_Click(object sender, EventArgs e)
        {
            // Display Date & Price of the lowest gas price
            GasPrice lowestPrice = GasPriceOperations.GetLowestPrice();
            MessageBox.Show($"Date: {lowestPrice.Date.ToString("d")}, Price: {lowestPrice.Price}");

        }
        #endregion

        #region Ascending & Descending Output Files
        private void ascendingButton_Click(object sender, EventArgs e)
        {
            GasPriceOperations.GenerateAscendingTextFile();
            MessageBox.Show("Output file has been created!");
        }

        private void descendingButton_Click(object sender, EventArgs e)
        {
           GasPriceOperations.GenerateDescendingTextFile();
            MessageBox.Show("Output file has been created!");
        }
        #endregion
    }
}

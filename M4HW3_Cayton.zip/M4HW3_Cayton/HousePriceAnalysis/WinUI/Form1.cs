﻿/**
* 11/1/2023
* CSC 253
* Max Cayton
* This program allows the user to search through a csv file containing house specifications based on range criteria.
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using HousePriceLibrary;


namespace WinUI
{
    public partial class Form1 : Form
    {
        
        public Form1()
        {
            // (int housePrice, int houseBedroomCount, double houseBathroomCount, int houseSquareFeet)
            InitializeComponent();

        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void SetListBox(ListBox listBox, List<House> houses)
        {
            // Method for setting the listbox
            listBox.Items.Clear();
            foreach (House house in houses) listBox.Items.Add(house);
        }

        private void searchButton_Click(object sender, EventArgs e)
        {
            try
            {               
                DisplayResults(resultListBox, Analysis.GetHouseList(),int.Parse(bedroomMinTextBox.Text), int.Parse(bedroomMaxTextBox.Text), double.Parse(bathroomMinTextBox.Text), double.Parse(bathroomMaxTextBox.Text), int.Parse(squareFeetMinTextBox.Text), int.Parse(squareFeetMaxTextBox.Text));
            }
            catch
            {
                MessageBox.Show("Something went wrong... Please try again.");
            }
        }

        private static void DisplayResults(ListBox listBox, List<House> houseList, int bedroomMin = -1, int bedroomMax = -1, double bathroomMin = -1.0, double bathroomMax = -1.0, int squareFeetMin = -1, int squareFeetMax = -1)
        {
            // Display the prices of each house that falls under the specified criteria (if any are applied)

            // Check which filters will actually be applied
            bool filterBedroom = (bedroomMin < 0 || bedroomMax < 0) ? false : true;
            bool filterBathroom = (bathroomMin < 0.0 || bathroomMax < 0.0) ? false : true;
            bool filterSquareFeet = (squareFeetMin < 0 || squareFeetMax < 0) ? false : true;

            // Send List through active filters
            if (filterBedroom == true)
            {
                houseList = houseList.FindAll(h => h.BedroomCount >= bedroomMin && h.BedroomCount <= bedroomMax);
            }

            if (filterBathroom == true)
            {
                houseList = houseList.FindAll(h => h.BathroomCount >= bathroomMin && h.BathroomCount <= bathroomMax);
            }

            if (filterSquareFeet == true)
            {
                houseList = houseList.FindAll(h => h.SquareFeet >= squareFeetMin && h.SquareFeet <= squareFeetMax);
            }

            // Apply list results to ListBox            
            listBox.Items.Clear();
            foreach (House house in houseList) listBox.Items.Add("Price: "+house.Price.ToString("c") + ",  Bedrooms: " +house.BedroomCount.ToString() + ",  Bathrooms: " + house.BathroomCount.ToString() + ",  Square Feet: " + house.SquareFeet.ToString());
            
        }

    }
}

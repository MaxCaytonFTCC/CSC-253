﻿/**
* 10/25/2023
* CSC 253
* Max Cayton
* This program allows the user to manipulate a list of random integers from a file by either removing negatives or displaying only in the 1-10 range.
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ListManipulatorLibrary;

namespace WinUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            // Initialize Input Group Box with file contents
            SetListBox(randomListBox,ListManipulator.LoadIntegerList());
        }

        private void reloadButton_Click(object sender, EventArgs e)
        {
            // Reloads values in first listbox if needed
            SetListBox(randomListBox, ListManipulator.LoadIntegerList());
        }

        private void SetListBox(ListBox listBox, List<int> ints)
        {
            // Method for setting the listbox
            listBox.Items.Clear();
            foreach (int i in ints) listBox.Items.Add(i);
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void removeNegativesButton_Click(object sender, EventArgs e)
        {
            // Remove Negatives & Display in second list box
            List<int> ints = ListManipulator.LoadIntegerList();
            ListManipulator.RemoveNegatives(ints);
            SetListBox(outputListBox, ints);
            
        }

        private void rangeButton_Click(object sender, EventArgs e)
        {
            // Display numbers in the 1-10 range in second list box
            List<int> ints = ListManipulator.LoadIntegerList();
            SetListBox(outputListBox, ListManipulator.GetWithinRange(ints));
        }
    }
}

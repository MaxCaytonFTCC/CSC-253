﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HousePriceLibrary
{
    public class House
    {
        // Properties
        public int Price { get; set; }
        public int BedroomCount { get; set; }
        public double BathroomCount { get; set; } // I'm not quite sure why the number of Bathrooms is a decimal number in the file but I went with it
        public int SquareFeet { get; set; }

        // Constructors
        public House() { } // Default Constructor

        public House(int housePrice, int houseBedroomCount, double houseBathroomCount, int houseSquareFeet)
        {
            Price = housePrice;
            BedroomCount = houseBedroomCount;
            BathroomCount = houseBathroomCount;
            SquareFeet = houseSquareFeet;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WordLibrary
{
    public static class UniqueWord
    {
        public static List<string> GetWordsFromFile()
        {
            List<string> words = new List<string>();

            using (StreamReader reader = File.OpenText(@"../../../WordLibrary/fruit_words.txt")) // I made a text file conatining 5 different types of fruit with 101 words total (with duplicates)
            {
                while (!reader.EndOfStream)
                {
                    words.Add(reader.ReadLine());
                }
            }
            return words;
        }

        public static List<string> RemoveDuplicates(List<string> wordsList)
        {
            return wordsList.Distinct().ToList();
        }
    }
}

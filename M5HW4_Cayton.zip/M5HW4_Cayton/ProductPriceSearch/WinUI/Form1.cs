﻿/**
* 11/20/2023
* CSC 253
* Max Cayton
* This program allows the user to search an MDF database file containing products for either a specific product number, or for product descriptions that contain specified text. Additionally, the user can search for prices with a specified range
*/
using ProductLibrary;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            resultsListBox.Items.Clear();
        }

        private void numberSearchButton_Click(object sender, EventArgs e)
        {
            SetListBox(resultsListBox,ProductOperations.GetProductNumberResults(productNumberTextBox.Text));
        }

        private void descSearchButton_Click(object sender, EventArgs e)
        {
            SetListBox(resultsListBox, ProductOperations.GetProductDescResults(descTextBox.Text));
        }

        private void SetListBox(ListBox lb, List<Product> list)
        {
            lb.Items.Clear();
            foreach (Product pro in list)
            {
                lb.Items.Add($"Product Number: {pro.Product_Number}, Product Desc: {pro.Description}, Price: {pro.Price}");
            }
        }

        private void showAllButton_Click(object sender, EventArgs e)
        {
            SetListBox(resultsListBox, ProductOperations.GetProductPriceAscending());
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Display Products in ascended order by price initially
            SetListBox(resultsListBox, ProductOperations.GetProductPriceAscending());
        }

        private void priceSearchButton_Click(object sender, EventArgs e)
        {
            // Display products with the specified range
            try
            {
                SetListBox(resultsListBox, ProductOperations.GetProductPriceRange(decimal.Parse(priceMinTextBox.Text), decimal.Parse(priceMaxTextBox.Text)));
            }
            catch
            {
                MessageBox.Show("Something went wrong... Please try again.");

                // Remove filter upon error
                SetListBox(resultsListBox, ProductOperations.GetProductPriceAscending());
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HousePriceLibrary
{
    public static class Analysis
    {
        public static List<House> GetHouseList()
        {
            List<House> houses = new List<House>();

            int index = 0;

            using (StreamReader reader = File.OpenText(@"../../../HousePriceLibrary/house_prices.csv"))
            {
                while (!reader.EndOfStream)
                {
                    string[] tokens = reader.ReadLine().Split(',');
                      
                    houses.Add(new House(int.Parse(tokens[0]), int.Parse(tokens[1]), double.Parse(tokens[2]), int.Parse(tokens[3])));
                    index++;                    
                }
            }

            return houses;

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeLibrary
{
    public class TeamLeader : ProductionWorker
    {
        // Default Constructor
        public TeamLeader() {
            MonthlyBonusAmount = 0.0m;
            RequiredTrainingHours = 0;
            NumTrainingHours = 0;
        }

        public decimal MonthlyBonusAmount { get; set; }
        public int RequiredTrainingHours { get; set; }
        public int NumTrainingHours { get; set; }

    }
}

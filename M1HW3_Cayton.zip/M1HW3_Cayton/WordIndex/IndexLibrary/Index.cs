﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Reflection;

namespace IndexLibrary
{
    public static class Index
    {        
        public static Dictionary<string,List<string>> indexDict = new Dictionary<string,List<string>>();

        public static void CreateIndex(string inputFilePath, string outputFilePath)
        {

            indexDict.Clear(); // Reset Dictionary

            StreamReader inputFile = File.OpenText(@inputFilePath);

            #region Creating the Word Index Dictionary
            string currentLine;
            int lineNumber = 1;

            while (!inputFile.EndOfStream)
            {
                currentLine = inputFile.ReadLine() + " ";

                string currentWord = "";

                for (int i = 0; i < currentLine.Length; i++)
                {
                    if (currentLine[i] != ' ')
                    {
                        currentWord += currentLine[i];
                    }
                    else
                    {
                        if (indexDict.ContainsKey(currentWord + ": "))
                        {                           
                            if (!indexDict[currentWord + ": "].Contains(lineNumber.ToString() + " ")) // Only add the index if it doesn't already exist in the word's list
                            {
                                indexDict[currentWord + ": "].Add(lineNumber.ToString() + " "); // If the word is already in the index, add the current line number that it is appearing again on
                            }                            
                        }
                        else
                        {
                            indexDict.Add(currentWord + ": ", new List<string>() {lineNumber.ToString() + " "}); // Add the key value pair of the new word with the current line number in a new list
                        }
                        currentWord = ""; // Reset the curent word
                    }
                    
                }
                lineNumber++; // Increment Line Number
            }
            inputFile.Close();
            #endregion

            #region Writing to Output File

            StreamWriter outputFile = File.CreateText(@outputFilePath);
            List<string> keysList = new List<string>(indexDict.Keys);

            AlphabeticalUpperCaseSort(keysList); // Sort according to the assignment's specific style

            // Add to output file
            foreach (string str in keysList)
            {
                string values = "";
                foreach (string val in indexDict[str])
                {
                    values += val;
                }
                outputFile.WriteLine(str + values);
            }

            outputFile.Close();
            #endregion

        }

        public static void AlphabeticalUpperCaseSort(List<string> list)
        {

            List<string> upperList = new List<string>(); // Make new list to hold sorted capital letters

            list.Sort(); // Sort alphabetically normally first

            for (int i = 0; i < list.Count; i++)
            {
                upperList.Add(list[i]); // Copy the first list
            }
            
            upperList.Sort(); // Sort upper list normally first

            for (int i = (list.Count - 1); i >= 0; i--) // Remove Capital Letters from first list
            {
                if (char.IsUpper(list[i][0]))
                {
                    list.RemoveAt(i);
                }
            }

            for (int i = (upperList.Count - 1); i >= 0; i--) // Remove all Lowercase Letters from second list
            {
                if (char.IsLower(upperList[i][0]))
                {
                    upperList.RemoveAt(i);
                }
            }

            list.InsertRange(0, upperList); // Append lists to complete sorting

        }

    }
}

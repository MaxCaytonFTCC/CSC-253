﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PrimeLibrary
{
    public static class PrimeNumber
    {

        public static List<int> GetPrimeNumbers(int inputInt)
        {
            // Create List of Integers From 2 Up through the Input Integer
            List<int> ints = new List<int>();
            for (int i = 2; i <= inputInt; i++)
            {
                ints.Add(i);
            }

            Predicate<int> IsPrime = x =>
            {
                // Use % to determine if the integer is divisible by any potential divisors
                for (int i = 2; i < x; i++)
                {
                    if (x % i == 0)
                    {
                        return false;
                    }
                }
                // Assume the integer is prime if the Predicate made it this far
                return true;
            };

            // Use Predicate on the List using FindAll
            List<int> primes = ints.FindAll(IsPrime);

            return primes;

        }

    }
}
